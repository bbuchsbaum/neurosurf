import * as THREE from 'three';
import { NeuroSurface, SurfaceGeometry, SurfaceConfig } from './classes';
import {
  LayerStack,
  BaseLayer,
  RGBALayer,
  DataLayer,
  TwoDataLayer,
  LabelLayer,
  Layer,
  TwoDataLayerConfig,
  VolumeProjectionLayer,
  VolumeProjectionMode,
  VolumeSamplingMode,
  VolumeProjectionQuality,
  RibbonSamplingConfig,
  LayerOrderDescriptor,
  LayerOrderResult
} from './layers';
import ColorMap2D, { ColorMap2DPreset } from './ColorMap2D';
import { CurvatureLayer } from './layers/CurvatureLayer';
import { ClipPlaneSet, ClipPlane, ClipAxis } from './utils/ClipPlane';
import { debugLog, isDebugEnabled } from './debug';
import ColorMap from './ColorMap';
import { GPULayerCompositor } from './GPULayerCompositor';
import { compositeStraightRGBABuffer, SURFACE_ALPHA_DISCARD_THRESHOLD } from './utils/rgbaCompositing';
import {
  createSurfaceShadingUniforms,
  installSurfaceShading,
  SURFACE_EDGE_ATTRIBUTE,
  SURFACE_OVERLAY_ATTRIBUTE,
  updateSurfaceShadingUniforms,
  writeThresholdEdgeSigns
} from './surface/SurfaceShading';
import type { SurfaceShadingOptions, SurfaceShadingUniforms } from './surface/SurfaceShading';
import { SurfaceColorUpdateScheduler } from './surface/SurfaceColorUpdateScheduler';
import {
  devicePixelRatio as normalizeDevicePixelRatio,
  finiteNumber
} from './utils/validation';
import { OutlineLayer } from './OutlineLayer';
import { ConnectivityLayer } from './ConnectivityLayer';
import { ParcelValueLayer, ParcelValueLayerConfig } from './layers/ParcelValueLayer';
import { TemporalDataLayer } from './temporal/TemporalDataLayer';
import type { ParcelData } from './parcellation';
import { LineSegments2 } from 'three/examples/jsm/lines/LineSegments2.js';
import { LineMaterial } from 'three/examples/jsm/lines/LineMaterial.js';
import { LineSegmentsGeometry } from 'three/examples/jsm/lines/LineSegmentsGeometry.js';

export interface MultiLayerSurfaceConfig extends SurfaceConfig {
  baseColor?: THREE.ColorRepresentation;
  metalness?: number;
  roughness?: number;
  useGPUCompositing?: boolean; // Enable GPU-accelerated compositing
  useWideLines?: boolean; // Use Line2 wide segments for outlines

  /** Pre-computed curvature data to display as underlay */
  curvature?: Float32Array | number[];
  /** Show curvature underlay (default: true if curvature provided) */
  showCurvature?: boolean;
  /** Curvature display options */
  curvatureOptions?: {
    brightness?: number;  // Base gray level (0-1), default 0.5
    contrast?: number;    // Curvature influence (0-1), default 0.5
    smoothness?: number;  // Curvature scaling factor, default 1
  };
  /** Fragment-level threshold edges, outline, and silhouette shading. */
  shading?: SurfaceShadingOptions;
}

type EdgeList = Array<[number, number]>;

function computeBoundaryEdges(
  faces: Uint32Array,
  roiLabels: ArrayLike<number>,
  roiSubset: number[] | null
): EdgeList {
  const edges: EdgeList = [];
  const seen = new Set<string>();
  const subset = roiSubset && roiSubset.length ? new Set(roiSubset) : null;

  const addEdge = (a: number, b: number) => {
    if (a === b) return;
    // Face indices and label length are validated against the same surface domain.
    const roiA = roiLabels[a]!;
    const roiB = roiLabels[b]!;
    if (roiA === roiB) return;
    if (subset && !subset.has(roiA) && !subset.has(roiB)) return;

    const keyA = a < b ? `${a}-${b}` : `${b}-${a}`;
    if (seen.has(keyA)) return;
    seen.add(keyA);
    edges.push(a < b ? [a, b] : [b, a]);
  };

  for (let i = 0; i < faces.length; i += 3) {
    // SurfaceGeometry guarantees complete, in-range triangles.
    const a = faces[i]!;
    const b = faces[i + 1]!;
    const c = faces[i + 2]!;
    addEdge(a, b);
    addEdge(b, c);
    addEdge(c, a);
  }

  return edges;
}

export interface LayerUpdate {
  id: string;
  type?: 'base' | 'rgba' | 'data' | 'outline' | 'label' | 'parcel' | 'curvature' | 'volume' | 'temporal';
  data?: Float32Array;
  indices?: Uint32Array;
  range?: [number, number];
  threshold?: [number, number];
  colormap?: ColorMap | string;
  colorMap?: ColorMap | string; // Allow both spellings
  cmap?: string;
  color?: THREE.ColorRepresentation;
  opacity?: number;
  visible?: boolean;
  blendMode?: 'normal' | 'additive' | 'multiply';
  order?: number;
  roiLabels?: Uint32Array | Int32Array | number[];
  halo?: boolean;
  haloColor?: THREE.ColorRepresentation;
  haloWidth?: number;
  width?: number;
  roiSubset?: number[] | null;
  offset?: number;
  labels?: Uint32Array | Int32Array | number[];
  labelDefs?: Array<{ id: number; color: THREE.ColorRepresentation; name?: string }>;
  defaultColor?: THREE.ColorRepresentation;
  parcelData?: ParcelData;
  vertexLabels?: Uint32Array | Int32Array | number[];
  valueColumn?: string;
  // Curvature layer properties
  curvature?: Float32Array | number[];
  brightness?: number;
  contrast?: number;
  smoothness?: number;

  // Temporal layer properties
  frames?: Float32Array[];
  times?: number[];
  factor?: import('./temporal/types').FactorDescriptor;

  // Volume projection layer properties
  volumeData?: Float32Array | number[];
  dims?: [number, number, number];
  worldToIJK?: THREE.Matrix4 | ArrayLike<number>;
  affineMatrix?: THREE.Matrix4 | ArrayLike<number>;
  affine?: ArrayLike<number>;
  voxelSize?: [number, number, number];
  volumeOrigin?: [number, number, number];
  useHalfFloat?: boolean;
  fillValue?: number;
  projectionMode?: VolumeProjectionMode;
  sampling?: VolumeSamplingMode;
  quality?: VolumeProjectionQuality;
  ribbon?: RibbonSamplingConfig;
}

export interface ClearLayersOptions {
  /**
   * When true, removes the base layer(s) as well. Defaults to false.
   */
  includeBase?: boolean;
}

/**
 * Multi-layer brain surface with flexible layer compositing
 */
export class MultiLayerNeuroSurface extends NeuroSurface {
  layerStack: LayerStack;
  compositeBuffer: Float32Array;
  vertexCount: number;
  private colorUpdates?: SurfaceColorUpdateScheduler;
  private useGPUCompositing: boolean;
  private gpuCompositingRequested: boolean;
  private gpuCompositor: GPULayerCompositor | null = null;
  private outlineResolution: THREE.Vector2 | null = null;
  private useWideLines: boolean;
  private shadingUniforms!: SurfaceShadingUniforms;
  private thresholdEdges = true;
  private overlayBuffer: Float32Array | null = null;
  private edgeBuffer: Float32Array | null = null;

  /** Clip plane set for surface clipping */
  readonly clipPlanes: ClipPlaneSet;

  constructor(geometry: SurfaceGeometry, config: MultiLayerSurfaceConfig = {}) {
    // Initialize with empty data
    const vertexCount = geometry.vertices.length / 3;
    // For visualization, we need indices for all vertices
    const indices = new Uint32Array(vertexCount);
    for (let i = 0; i < vertexCount; i++) {
      indices[i] = i;
    }
    
    // Pass empty data array for now
    super(geometry, indices, new Float32Array(vertexCount), config);
    
    this.layerStack = new LayerStack();
    this.compositeBuffer = new Float32Array(vertexCount * 4);
    this.vertexCount = vertexCount;
    this.colorUpdates = this.createColorUpdateScheduler();
    this.gpuCompositingRequested = config.useGPUCompositing ?? false;
    // Hardware capability belongs to the viewer renderer, which is attached later.
    this.useGPUCompositing = false;
    this.useWideLines = config.useWideLines ?? true;
    this.clipPlanes = new ClipPlaneSet();
    this.shadingUniforms = createSurfaceShadingUniforms(config.shading);
    this.thresholdEdges = config.shading?.thresholdEdges ?? true;
    
    // Add curvature layer if provided (renders below base layer)
    if (config.curvature && config.showCurvature !== false) {
      const curvOpts = config.curvatureOptions || {};
      const curvLayer = new CurvatureLayer('curvature', config.curvature, {
        order: -2, // Below base layer
        ...(curvOpts.brightness === undefined ? {} : { brightness: curvOpts.brightness }),
        ...(curvOpts.contrast === undefined ? {} : { contrast: curvOpts.contrast }),
        ...(curvOpts.smoothness === undefined ? {} : { smoothness: curvOpts.smoothness })
      });
      this.layerStack.addLayer(curvLayer);
      this.wireLayerChange(curvLayer);
      debugLog('CurvatureLayer added with', (config.curvature as any).length, 'vertices');
    }

    // Add base layer
    // If curvature is shown, the base layer should be hidden (curvature acts as underlay)
    const hasCurvature = config.curvature && config.showCurvature !== false;
    const baseColor = config.baseColor ?? 0xcccccc;
    const baseLayer = new BaseLayer(typeof baseColor === 'number' ? baseColor : new THREE.Color(baseColor).getHex(), {
      opacity: 1,
      visible: !hasCurvature  // Hide base layer when curvature is visible
    });
    this.layerStack.addLayer(baseLayer);
    this.wireLayerChange(baseLayer);

    // Create the mesh
    this.createMesh();
    
    // Initial color update
    this.updateColors();
  }

  /**
   * Toggle a simple edge wireframe for debugging/presentation. Creates if missing.
   */
  toggleWireframe(enabled: boolean): void {
    if (!this.mesh) return;
    const existing = this.mesh.getObjectByName('__WIREFRAME__') as THREE.LineSegments | undefined;
    if (enabled && !existing) {
      const edges = new THREE.EdgesGeometry(this.mesh.geometry as THREE.BufferGeometry, 5);
      const line = new THREE.LineSegments(
        edges,
        new THREE.LineBasicMaterial({ color: 0x444444, transparent: true, opacity: 0.6 })
      );
      line.name = '__WIREFRAME__';
      this.mesh.add(line);
    }
    const wire = this.mesh.getObjectByName('__WIREFRAME__');
    if (wire) wire.visible = enabled;
    if (this.mesh.material) {
      (this.mesh.material as any).visible = !enabled ? true : (this.mesh.material as any).visible;
    }
    this.emit('material:updated', { surface: this });
    this.requestColorUpdate();
  }

  /**
   * Build or rebuild the line objects for an outline layer and attach them to the surface mesh.
   */
  private applyOutlineLayer(layer: OutlineLayer): void {
    if (!this.mesh) return;

    // Dispose previous objects if any
    this.detachOutlineLayer(layer);

    const outlineObjects = this.buildOutlineObjects(layer);
    if (!outlineObjects) {
      debugLog('OutlineLayer', layer.id, ': no boundary edges found');
      return;
    }

    if (outlineObjects.halo) {
      outlineObjects.halo.renderOrder = (layer.order || 0) - 0.5;
      this.mesh.add(outlineObjects.halo);
      layer.haloObject = outlineObjects.halo;
    }

    outlineObjects.line.renderOrder = layer.order || 0;
    this.mesh.add(outlineObjects.line);
    layer.lineObject = outlineObjects.line;

    layer.needsUpdate = false;
    this.emit('layer:updated', { surface: this, layer });
    this.requestColorUpdate();
  }

  private detachOutlineLayer(layer: OutlineLayer): void {
    const mesh = this.mesh;
    if (!mesh) return;

    const removeObject = (obj: THREE.Object3D | null) => {
      if (!obj) return;
      if (obj.parent === mesh) {
        mesh.remove(obj);
      }
      obj.traverse(o => {
        const anyObj = o as any;
        if (anyObj.geometry?.dispose) {
          anyObj.geometry.dispose();
        }
        if (anyObj.material?.dispose) {
          anyObj.material.dispose();
        }
      });
    };

    removeObject(layer.lineObject);
    removeObject(layer.haloObject);
    layer.lineObject = null;
    layer.haloObject = null;
  }

  private ensureOutlineResolution(): void {
    if (!this.outlineResolution) {
      this.outlineResolution = new THREE.Vector2();
    }

    if (this.viewer && this.viewer.renderer && this.viewer.renderer.getSize) {
      this.viewer.renderer.getSize(this.outlineResolution);
    } else {
      this.outlineResolution.set(
        (this.viewer as any)?.width || 1,
        (this.viewer as any)?.height || 1
      );
    }
  }

  private setMaterialResolution(
    object: THREE.Object3D | null,
    width: number,
    height: number
  ): void {
    if (!object) return;
    object.traverse(o => {
      const mat = (o as any).material;
      if (mat && mat.resolution && typeof mat.resolution.set === 'function') {
        mat.resolution.set(width, height);
      }
    });
  }

  private buildOutlineObjects(layer: OutlineLayer): { line: THREE.LineSegments | LineSegments2; halo?: THREE.LineSegments | LineSegments2 } | null {
    if (!this.mesh) return null;

    if (layer.roiLabels.length !== this.vertexCount) {
      throw new RangeError(
        `OutlineLayer ${layer.id}: roiLabels length ${layer.roiLabels.length} ` +
        `does not match vertex count ${this.vertexCount}`
      );
    }

    const geometry = this.mesh.geometry as THREE.BufferGeometry;
    const positionAttr = geometry.getAttribute('position') as THREE.BufferAttribute;
    let normalAttr = geometry.getAttribute('normal') as THREE.BufferAttribute | undefined;

    if (!normalAttr) {
      geometry.computeVertexNormals();
      normalAttr = geometry.getAttribute('normal') as THREE.BufferAttribute;
    }

    if (!positionAttr || !normalAttr) return null;
    if (positionAttr.count !== this.vertexCount || normalAttr.count !== this.vertexCount) {
      throw new RangeError(
        `OutlineLayer ${layer.id}: position and normal attributes must contain ` +
        `${this.vertexCount} vertices`
      );
    }

    const edges = computeBoundaryEdges(this.geometry.faces, layer.roiLabels, layer.roiSubset);
    if (!edges.length) {
      return null;
    }

    const positions: number[] = [];
    const pos = positionAttr.array as ArrayLike<number>;
    const normals = normalAttr.array as ArrayLike<number>;
    const offset = layer.offset || 0;

    for (const [a, b] of edges) {
      const ax = pos[a * 3]!;
      const ay = pos[a * 3 + 1]!;
      const az = pos[a * 3 + 2]!;
      const bx = pos[b * 3]!;
      const by = pos[b * 3 + 1]!;
      const bz = pos[b * 3 + 2]!;

      const anx = normals[a * 3]!;
      const any = normals[a * 3 + 1]!;
      const anz = normals[a * 3 + 2]!;
      const bnx = normals[b * 3]!;
      const bny = normals[b * 3 + 1]!;
      const bnz = normals[b * 3 + 2]!;

      positions.push(
        ax + anx * offset,
        ay + any * offset,
        az + anz * offset,
        bx + bnx * offset,
        by + bny * offset,
        bz + bnz * offset
      );
    }

    this.ensureOutlineResolution();
    const resolutionX = this.outlineResolution?.x || 1;
    const resolutionY = this.outlineResolution?.y || 1;

    const lineGeom = this.useWideLines ? new LineSegmentsGeometry() : new THREE.BufferGeometry();
    if (lineGeom instanceof LineSegmentsGeometry) {
      lineGeom.setPositions(positions);
    } else {
      lineGeom.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    }

    const createMaterial = (color: number, width: number, opacity: number) => {
      if (this.useWideLines) {
        const mat = new LineMaterial({
          color,
          linewidth: width,
          transparent: opacity < 1,
          opacity,
          depthTest: true,
          depthWrite: false
        });
        mat.resolution.set(resolutionX, resolutionY);
        return mat;
      }
      return new THREE.LineBasicMaterial({
        color,
        transparent: opacity < 1,
        opacity
      });
    };

    const lineMat = createMaterial(layer.color, layer.width, layer.opacity);
    const line = this.useWideLines
      ? new LineSegments2(lineGeom as LineSegmentsGeometry, lineMat as LineMaterial)
      : new THREE.LineSegments(lineGeom as THREE.BufferGeometry, lineMat as THREE.LineBasicMaterial);
    line.visible = layer.visible;

    let halo: THREE.LineSegments | LineSegments2 | undefined;
    if (layer.halo) {
      const haloMat = createMaterial(
        layer.haloColor,
        layer.width + layer.haloWidth,
        Math.min(1, layer.opacity * 0.6)
      );
      const haloGeom = this.useWideLines ? (lineGeom as LineSegmentsGeometry).clone() : (lineGeom as THREE.BufferGeometry).clone();
      halo = this.useWideLines
        ? new LineSegments2(haloGeom as LineSegmentsGeometry, haloMat as LineMaterial)
        : new THREE.LineSegments(haloGeom as THREE.BufferGeometry, haloMat as THREE.LineBasicMaterial);
      halo.visible = layer.visible;
    }

    return halo === undefined ? { line } : { line, halo };
  }

  updateOutlineResolution(width: number, height: number, dpr: number = 1): void {
    const nextWidth = finiteNumber(width, 'width', { minimum: 0, minimumExclusive: true });
    const nextHeight = finiteNumber(height, 'height', { minimum: 0, minimumExclusive: true });
    const nextDpr = normalizeDevicePixelRatio(dpr);
    if (!this.outlineResolution) {
      this.outlineResolution = new THREE.Vector2();
    }
    this.outlineResolution.set(nextWidth * nextDpr, nextHeight * nextDpr);

    this.layerStack.getAllLayers().forEach(layer => {
      if (layer instanceof OutlineLayer) {
        this.setMaterialResolution(layer.lineObject, nextWidth * nextDpr, nextHeight * nextDpr);
        this.setMaterialResolution(layer.haloObject, nextWidth * nextDpr, nextHeight * nextDpr);
      }
    });
  }

  /**
   * Request a color update (throttled)
   */
  requestColorUpdate(): void {
    this.ensureColorUpdates().request();
  }

  /**
   * Composite a queued layer change immediately before a viewer paint.
   *
   * The viewer calls this at the start of render() so its already-scheduled
   * animation frame cannot paint stale vertex colors ahead of this surface's
   * independently queued compositing callback.
   */
  flushPendingColorUpdate(): boolean {
    return this.ensureColorUpdates().flush();
  }

  private createColorUpdateScheduler(): SurfaceColorUpdateScheduler {
    return new SurfaceColorUpdateScheduler({
      needsComposite: () => this.layerStack?.needsComposite ?? false,
      updateColors: () => this.updateColors(),
      onRenderNeeded: () => this.emit('render:needed', { surface: this })
    });
  }

  private ensureColorUpdates(): SurfaceColorUpdateScheduler {
    this.colorUpdates ??= this.createColorUpdateScheduler();
    return this.colorUpdates;
  }

  /**
   * Add a layer to the surface
   */
  addLayer(layer: Layer): void {
    layer._setDataSummaryDomainSize(this.vertexCount);
    this.layerStack.addLayer(layer);
    this.emit('layer:added', { surface: this, layer });

    this.wireLayerChange(layer);

    const maybeAttach = (layer as any).attach;
    if (typeof maybeAttach === 'function') {
      try {
        maybeAttach.call(layer, this);
      } catch (err) {
        console.warn(`MultiLayerNeuroSurface: failed to attach layer "${layer.id}"`, err);
      }
    }

    if (layer instanceof OutlineLayer) {
      this.applyOutlineLayer(layer);
    } else {
      this.requestColorUpdate();
    }
  }

  private wireLayerChange(layer: Layer): void {
    layer._onChangeCallback = (changes) => {
      const requiresComposite = Object.keys(changes).some(key => key !== 'presentation');
      try {
        this.emit('layer:updated', { surface: this, layer, changes: { ...changes } });
      } finally {
        if (requiresComposite) this.requestColorUpdate();
      }
    };
  }

  /**
   * Add a 2D data layer that maps two scalar fields to a 2D colormap.
   *
   * This is a convenience method for creating TwoDataLayer instances.
   *
   * @param id - Layer identifier
   * @param dataX - First scalar field (X axis of colormap)
   * @param dataY - Second scalar field (Y axis of colormap)
   * @param colorMap - 2D colormap preset name or ColorMap2D instance
   * @param config - Layer configuration options
   *
   * @example
   * ```typescript
   * // Visualize effect size vs. confidence
   * surface.addTwoDataLayer(
   *   'effect-confidence',
   *   effectSizeData,
   *   confidenceData,
   *   'confidence',
   *   {
   *     rangeX: [-2, 2],
   *     rangeY: [0, 1],
   *     thresholdY: [0, 0.05]  // Hide low-confidence values
   *   }
   * );
   * ```
   */
  addTwoDataLayer(
    id: string,
    dataX: Float32Array | number[],
    dataY: Float32Array | number[],
    colorMap: ColorMap2D | ColorMap2DPreset = 'confidence',
    config: TwoDataLayerConfig = {}
  ): TwoDataLayer {
    const layer = new TwoDataLayer(id, dataX, dataY, null, colorMap, config);
    this.addLayer(layer);
    return layer;
  }

  /**
   * Add a parcel-native value layer.
   *
   * Parcel values are expanded to vertices using the provided per-vertex
   * parcel labels.
   */
  addParcelValueLayer(
    id: string,
    parcelData: ParcelData,
    vertexLabels: Uint32Array | Int32Array | number[],
    colorMap: string = 'viridis',
    config: ParcelValueLayerConfig = {}
  ): ParcelValueLayer {
    const layer = new ParcelValueLayer(id, parcelData, vertexLabels, colorMap, config);
    this.addLayer(layer);
    return layer;
  }

  /**
   * Get a TwoDataLayer by ID (type-safe convenience method)
   */
  getTwoDataLayer(id: string): TwoDataLayer | undefined {
    const layer = this.layerStack.getLayer(id);
    return layer instanceof TwoDataLayer ? layer : undefined;
  }

  /**
   * Remove a layer by ID
   */
  removeLayer(id: string): boolean {
    const layer = this.layerStack.getLayer(id);
    if (layer instanceof OutlineLayer) {
      this.detachOutlineLayer(layer);
    }
    if (layer) {
      layer._onChangeCallback = null;
      layer._setDataSummaryDomainSize(null);
      const maybeDetach = (layer as any).detach;
      if (typeof maybeDetach === 'function') {
        try {
          maybeDetach.call(layer);
        } catch (err) {
          console.warn(`MultiLayerNeuroSurface: failed to detach layer "${layer.id}"`, err);
        }
      }
    }

    if (this.layerStack.removeLayer(id)) {
      this.emit('layer:removed', { surface: this, layerId: id });
      this.requestColorUpdate();
      return true;
    }
    return false;
  }

  /**
   * Remove all non-base layers (optionally including base).
   */
  clearLayers(options: ClearLayersOptions = {}): void {
    const includeBase = options.includeBase ?? false;

    this.layerStack.getAllLayers().forEach(layer => {
      const isBaseLayer = layer instanceof BaseLayer || layer.id.startsWith('base');
      if (!includeBase && isBaseLayer) {
        return;
      }
      this.removeLayer(layer.id);
    });
  }

  /**
   * Update a layer's properties
   */
  updateLayer(id: string, updates: Record<string, any>): void {
    this.layerStack.updateLayer(id, updates);
    const layer = this.layerStack.getLayer(id);
    if (layer instanceof OutlineLayer && layer.needsUpdate) {
      this.layerStack.needsComposite = false;
      this.applyOutlineLayer(layer);
    } else if (this.layerStack.needsComposite) {
      this.requestColorUpdate();
    }
  }

  updateLayerData(id: string, data: Float32Array | number[], indices?: Uint32Array | number[] | null): void {
    this.updateLayer(id, { data, indices });
  }

  updateLayerVisibility(id: string, visible: boolean): void {
    this.updateLayer(id, { visible });
  }

  /**
   * Get a layer by ID
   */
  getLayer(id: string): Layer | undefined {
    return this.layerStack.getLayer(id);
  }

  /**
   * Set curvature data for display as underlay.
   * Creates curvature layer if it doesn't exist.
   *
   * @param curvature - Curvature values per vertex
   * @param options - Display options (brightness, contrast, smoothness)
   */
  setCurvature(
    curvature: Float32Array | number[],
    options?: { brightness?: number; contrast?: number; smoothness?: number }
  ): void {
    const existing = this.layerStack.getLayer('curvature');
    if (existing && existing instanceof CurvatureLayer) {
      existing.setCurvature(curvature);
      if (options?.brightness !== undefined) existing.setBrightness(options.brightness);
      if (options?.contrast !== undefined) existing.setContrast(options.contrast);
      if (options?.smoothness !== undefined) existing.setSmoothness(options.smoothness);
    } else {
      const layer = new CurvatureLayer('curvature', curvature, {
        order: -2,
        ...(options?.brightness === undefined ? {} : { brightness: options.brightness }),
        ...(options?.contrast === undefined ? {} : { contrast: options.contrast }),
        ...(options?.smoothness === undefined ? {} : { smoothness: options.smoothness })
      });
      this.layerStack.addLayer(layer);
      this.wireLayerChange(layer);
    }
    this.requestColorUpdate();
  }

  /**
   * Get the curvature layer if it exists
   */
  getCurvatureLayer(): CurvatureLayer | undefined {
    const layer = this.layerStack.getLayer('curvature');
    return layer instanceof CurvatureLayer ? layer : undefined;
  }

  /**
   * Toggle curvature visibility.
   * When curvature is shown, the base layer is hidden (curvature acts as the underlay).
   * When curvature is hidden, the base layer is shown.
   */
  showCurvature(visible: boolean): void {
    const curvLayer = this.getCurvatureLayer();
    const baseLayer = this.layerStack.getLayer('base');

    if (curvLayer) {
      curvLayer.setVisible(visible);
    }

    // Base layer visibility is inverse of curvature visibility
    // When curvature is shown, it acts as the underlay instead of the base color
    if (baseLayer) {
      baseLayer.setVisible(!visible);
    }

    this.requestColorUpdate();
  }

  // ============================================================
  // Clip Plane Methods
  // ============================================================

  /**
   * Set a clip plane by axis.
   *
   * @param axis - Which axis to clip ('x', 'y', or 'z')
   * @param distance - Distance from origin along axis
   * @param enabled - Whether to enable (default: true)
   * @param flip - Flip clipping direction (default: false)
   *
   * @example
   * // Clip at x=0 (midline sagittal cut)
   * surface.setClipPlane('x', 0);
   *
   * // Clip right hemisphere only
   * surface.setClipPlane('x', 0, true, true);
   */
  setClipPlane(
    axis: ClipAxis,
    distance: number,
    enabled = true,
    flip = false
  ): void {
    this.clipPlanes.setClipPlane(axis, distance, enabled, flip);
    this._syncClipPlanes();
    this.emit('material:updated', { surface: this });
    this.requestColorUpdate();
  }

  /**
   * Enable a clip plane.
   */
  enableClipPlane(axis: ClipAxis): void {
    this.clipPlanes.enableClipPlane(axis);
    this._syncClipPlanes();
    this.emit('material:updated', { surface: this });
    this.requestColorUpdate();
  }

  /**
   * Disable a clip plane.
   */
  disableClipPlane(axis: ClipAxis): void {
    this.clipPlanes.disableClipPlane(axis);
    this._syncClipPlanes();
    this.emit('material:updated', { surface: this });
    this.requestColorUpdate();
  }

  /**
   * Clear all clip planes (disable all).
   */
  clearClipPlanes(): void {
    this.clipPlanes.clearClipPlanes();
    this._syncClipPlanes();
    this.emit('material:updated', { surface: this });
    this.requestColorUpdate();
  }

  /**
   * Get a clip plane by axis.
   */
  getClipPlane(axis: ClipAxis): ClipPlane {
    return this.clipPlanes.getClipPlane(axis);
  }

  /**
   * Sync clip planes to both CPU and GPU materials.
   */
  private _syncClipPlanes(): void {
    // Sync to GPU compositor
    if (this.gpuCompositor) {
      this.gpuCompositor.setClipPlanes(this.clipPlanes);
    }

    // Sync to CPU material
    if (this.mesh && this.mesh.material) {
      const material = this.mesh.material as THREE.Material;
      if ('clippingPlanes' in material) {
        const threePlanes = this.clipPlanes.getThreePlanes();
        (material as any).clippingPlanes = threePlanes.length > 0 ? threePlanes : null;
        material.needsUpdate = true;
      }
    }

    // Sync to connectivity layer materials
    const threePlanes2 = this.clipPlanes.getThreePlanes();
    this.layerStack.getAllLayers().forEach(layer => {
      if (layer instanceof ConnectivityLayer) {
        layer.setClipPlanes(threePlanes2.length > 0 ? threePlanes2 : null);
      }
    });

    // Enable clipping on the renderer if we have any planes
    if (this.viewer?.renderer) {
      this.viewer.renderer.localClippingEnabled = this.clipPlanes.hasEnabledPlanes();
    }
  }

  /**
   * Return the exact bottom-to-top layer order used by compositing.
   */
  getOrderedLayers(): readonly Layer[] {
    return this.layerStack.getOrderedLayers();
  }

  getLayerOrderDescriptors(): readonly LayerOrderDescriptor[] {
    return this.layerStack.getLayerOrderDescriptors();
  }

  /** Validate a complete bottom-to-top order without mutating the surface. */
  validateLayerOrder(ids: readonly string[]): LayerOrderResult {
    return this.layerStack.validateLayerOrder(ids);
  }

  /**
   * Atomically set the complete bottom-to-top layer order.
   */
  setLayerOrder(ids: readonly string[]): LayerOrderResult {
    const previousOrder = this.layerStack.getOrderedLayers().map(layer => layer.id);
    const result = this.layerStack.setLayerOrder(ids);
    if (!result.ok || !result.changed) return result;

    this.emit('layer:reordered', {
      surface: this,
      order: result.order,
      previousOrder: Object.freeze(previousOrder)
    });
    this.requestColorUpdate();
    return result;
  }

  moveLayer(layerId: string, destinationIndex: number): LayerOrderResult {
    const previousOrder = this.layerStack.getOrderedLayers().map(layer => layer.id);
    const result = this.layerStack.moveLayer(layerId, destinationIndex);
    if (!result.ok || !result.changed) return result;

    this.emit('layer:reordered', {
      surface: this,
      order: result.order,
      previousOrder: Object.freeze(previousOrder),
      movedLayerId: layerId
    });
    this.requestColorUpdate();
    return result;
  }

  /**
   * Batch update multiple layers
   */
  updateLayers(updates: LayerUpdate[]): void {
    let needsUpdate = false;
    
    updates.forEach(update => {
      const { id, type, ...props } = update;
      
      if (type) {
        // Create new layer
        let layer: Layer | null = null;
        switch (type) {
          case 'base': {
            const color = props.color || 0xcccccc;
            layer = new BaseLayer(typeof color === 'number' ? color : new THREE.Color(color).getHex(), props);
            break;
          }
          case 'rgba':
            if (props.data) {
              layer = new RGBALayer(id, props.data, props);
            }
            break;
          case 'data':
            if (props.data && props.indices) {
              const colormap = props.colormap || props.colorMap;
              layer = new DataLayer(id, props.data, props.indices, colormap || 'jet', props);
            }
            break;
          case 'volume':
            if (props.volumeData && props.dims) {
              const colormapName = typeof props.colormap === 'string'
                ? props.colormap
                : (props.cmap ?? 'viridis');
              layer = new VolumeProjectionLayer(
                id,
                props.volumeData,
                props.dims,
                {
                  colormap: colormapName,
                  ...(props.range === undefined ? {} : { range: props.range }),
                  ...(props.threshold === undefined ? {} : { threshold: props.threshold }),
                  ...(props.worldToIJK === undefined ? {} : { worldToIJK: props.worldToIJK }),
                  ...((props.affineMatrix ?? props.affine) === undefined
                    ? {}
                    : { affineMatrix: props.affineMatrix ?? props.affine }),
                  ...(props.voxelSize === undefined ? {} : { voxelSize: props.voxelSize }),
                  ...(props.volumeOrigin === undefined ? {} : { volumeOrigin: props.volumeOrigin }),
                  ...(props.useHalfFloat === undefined ? {} : { useHalfFloat: props.useHalfFloat }),
                  ...(props.fillValue === undefined ? {} : { fillValue: props.fillValue }),
                  ...(props.projectionMode === undefined ? {} : { projectionMode: props.projectionMode }),
                  ...(props.sampling === undefined ? {} : { sampling: props.sampling }),
                  ...(props.quality === undefined ? {} : { quality: props.quality }),
                  ...(props.ribbon === undefined ? {} : { ribbon: props.ribbon }),
                  ...(props.visible === undefined ? {} : { visible: props.visible }),
                  ...(props.opacity === undefined ? {} : { opacity: props.opacity }),
                  ...(props.blendMode === undefined ? {} : { blendMode: props.blendMode }),
                  ...(props.order === undefined ? {} : { order: props.order })
                }
              );
            }
            break;
          case 'label':
            if (props.labels && props.labelDefs) {
              layer = new LabelLayer(id, {
                labels: props.labels,
                labelDefs: props.labelDefs,
                ...(props.defaultColor === undefined ? {} : { defaultColor: props.defaultColor }),
                ...(props.visible === undefined ? {} : { visible: props.visible }),
                ...(props.opacity === undefined ? {} : { opacity: props.opacity }),
                ...(props.blendMode === undefined ? {} : { blendMode: props.blendMode }),
                ...(props.order === undefined ? {} : { order: props.order })
              });
            }
            break;
          case 'parcel':
            if (props.parcelData && props.vertexLabels) {
              const colormapParcel =
                typeof props.colormap === 'string'
                  ? props.colormap
                  : (props.cmap ?? 'viridis');
              layer = new ParcelValueLayer(id, props.parcelData, props.vertexLabels, colormapParcel, {
                ...(props.valueColumn === undefined ? {} : { valueColumn: props.valueColumn }),
                ...(props.range === undefined ? {} : { range: props.range }),
                ...(props.threshold === undefined ? {} : { threshold: props.threshold }),
                ...(props.visible === undefined ? {} : { visible: props.visible }),
                ...(props.opacity === undefined ? {} : { opacity: props.opacity }),
                ...(props.blendMode === undefined ? {} : { blendMode: props.blendMode }),
                ...(props.order === undefined ? {} : { order: props.order })
              });
            }
            break;
          case 'outline':
            if (props.roiLabels) {
              layer = new OutlineLayer(id, {
                roiLabels: props.roiLabels,
                ...(props.color === undefined ? {} : { color: props.color }),
                ...(props.width === undefined ? {} : { width: props.width }),
                ...(props.opacity === undefined ? {} : { opacity: props.opacity }),
                ...(props.halo === undefined ? {} : { halo: props.halo }),
                ...(props.haloColor === undefined ? {} : { haloColor: props.haloColor }),
                ...(props.haloWidth === undefined ? {} : { haloWidth: props.haloWidth }),
                ...(props.offset === undefined ? {} : { offset: props.offset }),
                ...(props.roiSubset === undefined ? {} : { roiSubset: props.roiSubset }),
                ...(props.visible === undefined ? {} : { visible: props.visible }),
                ...(props.blendMode === undefined ? {} : { blendMode: props.blendMode }),
                ...(props.order === undefined ? {} : { order: props.order })
              });
            }
            break;
          case 'temporal':
            if (props.frames && props.times) {
              const colormapTemporal = props.colormap || props.colorMap || props.cmap || 'jet';
              layer = new TemporalDataLayer(
                id,
                props.frames,
                props.times,
                colormapTemporal,
                {
                  ...(props.range === undefined ? {} : { range: props.range }),
                  ...(props.threshold === undefined ? {} : { threshold: props.threshold }),
                  ...(props.factor === undefined ? {} : { factor: props.factor }),
                  ...(props.visible === undefined ? {} : { visible: props.visible }),
                  ...(props.opacity === undefined ? {} : { opacity: props.opacity }),
                  ...(props.blendMode === undefined ? {} : { blendMode: props.blendMode }),
                  ...(props.order === undefined ? {} : { order: props.order })
                }
              );
            }
            break;
          case 'curvature':
            if (props.curvature) {
              layer = new CurvatureLayer(id, props.curvature, {
                order: props.order ?? -2,
                ...(props.brightness === undefined ? {} : { brightness: props.brightness }),
                ...(props.contrast === undefined ? {} : { contrast: props.contrast }),
                ...(props.smoothness === undefined ? {} : { smoothness: props.smoothness }),
                ...(props.visible === undefined ? {} : { visible: props.visible }),
                ...(props.opacity === undefined ? {} : { opacity: props.opacity }),
                ...(props.blendMode === undefined ? {} : { blendMode: props.blendMode })
              });
            }
            break;
          default:
            console.warn(`Unknown layer type: ${type}`);
            return;
        }
        
        if (layer) {
          layer._setDataSummaryDomainSize(this.vertexCount);
          this.layerStack.addLayer(layer);
          this.wireLayerChange(layer);
          const maybeAttach = (layer as any).attach;
          if (typeof maybeAttach === 'function') {
            try {
              maybeAttach.call(layer, this);
            } catch (err) {
              console.warn(`MultiLayerNeuroSurface: failed to attach layer "${layer.id}"`, err);
            }
          }
          if (layer instanceof OutlineLayer) {
            this.applyOutlineLayer(layer);
          }
          needsUpdate = true;
        }
      } else {
        // Update existing layer
        this.layerStack.updateLayer(id, props);
        if (this.layerStack.getLayer(id) instanceof OutlineLayer) {
          const outlineLayer = this.layerStack.getLayer(id) as OutlineLayer;
          if (outlineLayer.needsUpdate) {
            this.applyOutlineLayer(outlineLayer);
          }
        }
        needsUpdate = needsUpdate || this.layerStack.needsComposite;
      }
    });
    
    if (needsUpdate) {
      const firstUpdate = updates[0];
      const updatedLayer = firstUpdate ? this.layerStack.getLayer(firstUpdate.id) : undefined;
      if (updatedLayer) this.emit('layer:updated', { surface: this, layer: updatedLayer });
      this.requestColorUpdate();
    }
  }

  /**
   * Composite all layers and update mesh colors
   */
  updateColors(): void {
    if (!this.mesh) {
      debugLog('MultiLayerNeuroSurface: No mesh to update');
      return;
    }
    
    debugLog('MultiLayerNeuroSurface: Updating colors');
    
    // Use GPU compositor if available
    if (this.useGPUCompositing && this.gpuCompositor) {
      this.updateColorsGPU();
      return;
    }
    
    // Fall back to CPU compositing
    this.updateColorsCPU();
  }

  /**
   * Update colors using GPU compositor
   */
  private updateColorsGPU(): void {
    if (!this.gpuCompositor) return;
    
    const visibleLayers = this.layerStack
      .getVisibleLayers()
      .filter(layer => !(layer instanceof OutlineLayer) && !(layer instanceof ConnectivityLayer));
    this.gpuCompositor.updateLayers(visibleLayers);
    visibleLayers.forEach(layer => (layer.needsUpdate = false));
    
    // Mark as updated
    this.layerStack.needsComposite = false;
    
    // Request render
    if (this.viewer && this.viewer.requestRender) {
      this.viewer.requestRender();
    }
  }

  /**
   * Update colors using CPU compositing (original method)
   */
  private updateColorsCPU(): void {
    // Every visible color, including the anatomical base, is an ordered layer.
    // A genuinely empty/hidden stack therefore remains transparent.
    this.compositeBuffer.fill(0);

    // Get visible layers in order
    const visibleLayers = this.layerStack
      .getVisibleLayers()
      .filter(layer => !(layer instanceof OutlineLayer) && !(layer instanceof ConnectivityLayer));

    debugLog('MultiLayerNeuroSurface: updateColorsCPU found', visibleLayers.length, 'visible layers');

    if (visibleLayers.length === 0) {
      debugLog('No visible layers');
      this.applyCompositeToMesh();
      return;
    }

    const collectDebugStats = isDebugEnabled();
    const edgeLayer = this.thresholdEdgeLayer(visibleLayers);

    // Composite each layer
    for (const layer of visibleLayers) {
      if (layer === edgeLayer) continue;
      try {
        debugLog('MultiLayerNeuroSurface: Processing layer', layer.id, '(type:', layer.constructor.name, ')');
        const layerRGBA = layer.getRGBAData(this.vertexCount);
        const expectedLength = this.vertexCount * 4;
        if (layerRGBA.length !== expectedLength) {
          throw new RangeError(
            `Layer ${layer.id} returned ${layerRGBA.length} RGBA values; expected ${expectedLength}`
          );
        }

        // Debug: sample first few values
        if (collectDebugStats && layerRGBA.length >= 8) {
          const sample = Array.from(layerRGBA.slice(0, 8)).map(v => v.toFixed(3));
          debugLog(`MultiLayerNeuroSurface: Layer ${layer.id} RGBA sample [0..7]: ${sample.join(', ')}`);
        }

        if (collectDebugStats) {
          let nonTransparentCount = 0;
          for (let i = 3; i < layerRGBA.length; i += 4) {
            if (layerRGBA[i]! > 0) nonTransparentCount++;
          }
          debugLog(`MultiLayerNeuroSurface: Layer ${layer.id} has ${nonTransparentCount}/${this.vertexCount} non-transparent vertices`);
        }

        this.compositeLayer(layerRGBA, layer);
        layer.needsUpdate = false;
      } catch (error) {
        console.error(`Error processing layer ${layer.id}:`, error);
      }
    }

    this.applyThresholdEdges(edgeLayer);

    // Apply composite to mesh
    this.applyCompositeToMesh();

    // Mark as updated
    this.layerStack.needsComposite = false;

    // Request render
    if (this.viewer && this.viewer.requestRender) {
      this.viewer.requestRender();
    }
  }

  /**
   * The layer drawn with fragment-level threshold edges: the top-most visible
   * colour layer when it is a plain DataLayer with an active mask and normal
   * blending. Parcel, temporal and statistical subclasses keep per-vertex
   * edges, since their values are not meant to be interpolated.
   */
  private thresholdEdgeLayer(visibleLayers: Layer[]): DataLayer | null {
    if (!this.thresholdEdges || !this.mesh) return null;
    const top = visibleLayers[visibleLayers.length - 1];
    if (!(top instanceof DataLayer) || Object.getPrototypeOf(top) !== DataLayer.prototype ||
        top.blendMode !== 'normal') {
      return null;
    }
    const [low, high] = top.getThreshold();
    return high > low ? top : null;
  }

  private applyThresholdEdges(layer: DataLayer | null): void {
    if (!this.mesh) return;
    const geometry = this.mesh.geometry as THREE.BufferGeometry;
    const overlay = geometry.getAttribute(SURFACE_OVERLAY_ATTRIBUTE) as THREE.BufferAttribute | undefined;
    const edge = geometry.getAttribute(SURFACE_EDGE_ATTRIBUTE) as THREE.BufferAttribute | undefined;
    if (!overlay || !edge) {
      this.shadingUniforms.surfviewEdgeEnabled.value = 0;
      return;
    }
    let enabled = false;
    if (layer) {
      try {
        enabled = layer.writeThresholdEdgeAttributes(
          this.vertexCount,
          overlay.array as Float32Array,
          edge.array as Float32Array
        );
        if (enabled) {
          // The shader draws the contour between shown and hidden vertices,
          // so it needs each vertex's visibility, not its distance.
          writeThresholdEdgeSigns(edge.array as Float32Array);
          const colors = overlay.array as Float32Array;
          const opacity = layer.opacity;
          for (let offset = 3; offset < colors.length; offset += 4) colors[offset]! *= opacity;
        }
        layer.needsUpdate = false;
      } catch (error) {
        console.error(`Error preparing threshold edges for layer ${layer.id}:`, error);
        enabled = false;
      }
      if (!enabled) {
        // Fall back to the per-vertex path for this layer.
        this.compositeLayer(layer.getRGBAData(this.vertexCount), layer);
      }
    }
    overlay.needsUpdate = true;
    edge.needsUpdate = true;
    this.shadingUniforms.surfviewEdgeEnabled.value = enabled ? 1 : 0;
  }

  /** Update fragment-level shading (threshold edges, outline, silhouette). */
  setShading(options: SurfaceShadingOptions): void {
    updateSurfaceShadingUniforms(this.shadingUniforms, options);
    if (options.thresholdEdges !== undefined && options.thresholdEdges !== this.thresholdEdges) {
      this.thresholdEdges = options.thresholdEdges;
      this.layerStack.needsComposite = true;
      this.requestColorUpdate();
    }
    if (this.viewer && this.viewer.requestRender) this.viewer.requestRender();
  }

  /**
   * Composite a single layer into the buffer
   */
  private compositeLayer(layerRGBA: Float32Array, layer: Layer): void {
    compositeStraightRGBABuffer(
      this.compositeBuffer,
      layerRGBA,
      layer.blendMode,
      layer.opacity
    );
  }

  /**
   * Apply the composite buffer to the mesh
   */
  private applyCompositeToMesh(): void {
    if (!this.mesh) return;

    const geometry = this.mesh.geometry as THREE.BufferGeometry;
    const material = this.mesh.material as THREE.MeshPhongMaterial;

    // Get or create color attribute
    let colorAttribute = geometry.getAttribute('color') as THREE.BufferAttribute | undefined;

    if (!colorAttribute) {
      // Create new attribute with its own buffer
      const colorBuffer = new Float32Array(this.vertexCount * 4);
      colorAttribute = new THREE.BufferAttribute(colorBuffer, 4);
      geometry.setAttribute('color', colorAttribute);
    }

    // Always copy data to the attribute's buffer
    const colors = colorAttribute.array as Float32Array;
    if (colors.length === this.compositeBuffer.length) {
      colors.set(this.compositeBuffer);
    } else {
      console.error('Color attribute size mismatch');
      return;
    }

    colorAttribute.needsUpdate = true;
    // Only enable vertex colors AFTER valid data exists. A fully opaque
    // composite must render opaque with depth writes: with depthWrite off,
    // triangles draw in index order, so wherever the closed surface overlaps
    // itself on screen (an inflated insula seen from above, a frontal fold
    // seen head-on) far-side triangles paint over near-side ones and show as
    // cracks and hatching. Only a genuinely translucent composite keeps the
    // sorted-transparency path.
    const opaque = this.compositeIsOpaque();
    const wasTransparent = material.transparent;
    material.vertexColors = true;
    material.transparent = !opaque;
    material.depthTest = true;
    material.depthWrite = opaque;
    // Fully transparent fragments are discarded so they never draw or write depth.
    material.alphaTest = SURFACE_ALPHA_DISCARD_THRESHOLD;
    material.blending = THREE.NormalBlending;
    material.premultipliedAlpha = false;
    if (wasTransparent !== material.transparent || !material.userData.surfviewColorsApplied) {
      material.userData.surfviewColorsApplied = true;
      material.needsUpdate = true;
    }

    debugLog('MultiLayerNeuroSurface: Applied vertex colors to mesh');

    if (isDebugEnabled()) {
      debugLog('MultiLayerNeuroSurface: Mesh state:', {
        meshExists: !!this.mesh,
        geometryExists: !!geometry,
        positionCount: geometry.getAttribute('position')?.count,
        colorCount: colorAttribute.count,
        indexCount: geometry.getIndex()?.count,
        materialVertexColors: material.vertexColors,
        materialVisible: material.visible,
        meshVisible: this.mesh?.visible,
      });
    }

    // Only compute bounding box/sphere if not already computed
    // (positions don't change during color updates)
    if (!geometry.boundingBox) {
      geometry.computeBoundingBox();
    }
    if (!geometry.boundingSphere) {
      geometry.computeBoundingSphere();
    }
  }

  private compositeIsOpaque(): boolean {
    if ((this.config.alpha ?? 1) < 1) return false;
    const buffer = this.compositeBuffer;
    for (let offset = 3; offset < buffer.length; offset += 4) {
      if (buffer[offset]! < 0.999) return false;
    }
    return true;
  }

  /**
   * Create fallback material for CPU compositing
   * NOTE: Start with vertexColors: false until color attribute is populated with valid data
   */
  private createFallbackMaterial(): THREE.MeshPhongMaterial {
    const material = new THREE.MeshPhongMaterial({
      vertexColors: false, // Start false until color attribute has valid data
      transparent: true,
      depthTest: true,
      depthWrite: true,
      alphaTest: SURFACE_ALPHA_DISCARD_THRESHOLD,
      blending: THREE.NormalBlending,
      premultipliedAlpha: false,
      opacity: 1, // We handle opacity per-vertex
      shininess: this.config.shininess ?? 30,
      specular: new THREE.Color(this.config.specularColor ?? 0x111111),
      flatShading: this.config.flatShading ?? false,
      side: THREE.DoubleSide, // Ensure both sides are visible
      color: new THREE.Color((this.config as MultiLayerSurfaceConfig).baseColor ?? 0xcccccc)
    });
    installSurfaceShading(material, this.shadingUniforms);
    return material;
  }

  /**
   * Create mesh with proper material settings
   */
  createMesh(): THREE.Mesh {
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(this.geometry.vertices, 3));
    geometry.setIndex(new THREE.Uint32BufferAttribute(this.geometry.faces, 1));

    // Add vertexIndex attribute for GPU compositing shader
    const vertexIndices = new Float32Array(this.vertexCount);
    for (let i = 0; i < this.vertexCount; i++) {
      vertexIndices[i] = i;
    }
    geometry.setAttribute('vertexIndex', new THREE.Float32BufferAttribute(vertexIndices, 1));
    this.overlayBuffer = new Float32Array(this.vertexCount * 4);
    this.edgeBuffer = new Float32Array(this.vertexCount).fill(-1);
    geometry.setAttribute(SURFACE_OVERLAY_ATTRIBUTE, new THREE.BufferAttribute(this.overlayBuffer, 4));
    geometry.setAttribute(SURFACE_EDGE_ATTRIBUTE, new THREE.BufferAttribute(this.edgeBuffer, 1));

    let material: THREE.Material;

    if (this.useGPUCompositing && this.gpuCompositor) {
      // Use GPU shader material for compositing
      material = this.gpuCompositor.getMaterial() || this.createFallbackMaterial();
    } else {
      // Use standard material for CPU compositing
      material = this.createFallbackMaterial();
    }

    this.mesh = new THREE.Mesh(geometry, material);

    // Compute vertex normals for better lighting
    geometry.computeVertexNormals();

    // Compute bounding box/sphere for camera centering
    geometry.computeBoundingBox();
    geometry.computeBoundingSphere();

    if (isDebugEnabled()) {
      debugLog('MultiLayerNeuroSurface: createMesh complete', {
        vertexCount: this.geometry.vertices.length / 3,
        faceCount: this.geometry.faces.length / 3,
        boundingSphereRadius: geometry.boundingSphere?.radius,
        boundingSphereCenter: geometry.boundingSphere?.center.toArray(),
      });
    }

    // Initial color update
    this.updateColors();

    return this.mesh;
  }

  /**
   * Switch compositing mode between CPU and GPU
   */
  setCompositingMode(useGPU: boolean): void {
    this.gpuCompositingRequested = useGPU;
    if (useGPU === this.useGPUCompositing) return; // No change needed
    
    this.useGPUCompositing = useGPU;
    
    if (useGPU) {
      const capacity = this.assessGPUCompositingCapacity();
      if (!capacity.supported) {
        console.warn(`GPU compositing unavailable: ${capacity.reason}; keeping CPU mode`);
        this.useGPUCompositing = false;
        return;
      }
      // Switch to GPU compositing
      if (!this.gpuCompositor) {
        try {
          this.gpuCompositor = new GPULayerCompositor(this.vertexCount);
          debugLog('Switched to GPU compositing');
        } catch (error) {
          console.warn('Failed to initialize GPU compositor:', error);
          this.useGPUCompositing = false;
          return;
        }
      }
      
      // Replace material with shader material
      if (this.mesh && this.gpuCompositor) {
        const oldMaterial = this.mesh.material;
        this.mesh.material = this.gpuCompositor.getMaterial() || this.createFallbackMaterial();
        
        // Dispose old material
        if (oldMaterial && 'dispose' in oldMaterial) {
          (oldMaterial as THREE.Material).dispose();
        }
      }
    } else {
      // Switch to CPU compositing
      if (this.mesh) {
        const oldMaterial = this.mesh.material;
        this.mesh.material = this.createFallbackMaterial();
        
        // Dispose old material
        if (oldMaterial && 'dispose' in oldMaterial) {
          (oldMaterial as THREE.Material).dispose();
        }
      }
      
      // Optionally dispose GPU compositor to free memory
      if (this.gpuCompositor) {
        this.gpuCompositor.dispose();
        this.gpuCompositor = null;
      }
      
      debugLog('Switched to CPU compositing');
    }
    
    // Update colors with new method
    this.updateColors();
    this.emit('material:updated', { surface: this });
  }

  /** Activate the constructor-requested GPU path once a viewer renderer exists. */
  activateConfiguredCompositor(): void {
    if (this.gpuCompositingRequested) {
      this.setCompositingMode(true);
    }
  }

  setWideLines(useWide: boolean): void {
    if (useWide === this.useWideLines) return;
    this.useWideLines = useWide;

    // Rebuild all outline layers with the new line implementation
    this.layerStack.getAllLayers().forEach(layer => {
      if (layer instanceof OutlineLayer) {
        this.applyOutlineLayer(layer);
      }
    });

    this.emit('material:updated', { surface: this });
    this.requestColorUpdate();
  }

  /**
   * Get current compositing mode
   */
  getCompositingMode(): 'CPU' | 'GPU' {
    return this.useGPUCompositing ? 'GPU' : 'CPU';
  }

  private assessGPUCompositingCapacity(): ReturnType<typeof GPULayerCompositor.assessCapacity> {
    const renderer = (this.viewer as any)?.renderer;
    if (!renderer?.capabilities) {
      return Object.freeze({
        supported: false,
        reason: 'a viewer WebGL renderer is required',
        requiredVertexTextureUnits: 10,
        availableVertexTextureUnits: 0,
        requiredTextureSize: Math.ceil(Math.sqrt(this.vertexCount)),
        availableTextureSize: 0
      });
    }
    return GPULayerCompositor.assessCapacity(renderer, this.vertexCount);
  }

  /**
   * Dispose of all resources
   */
  dispose(): void {
    this.colorUpdates?.dispose();
    // Remove outline and connectivity objects to avoid orphaned materials
    this.layerStack.getAllLayers().forEach(layer => {
      if (layer instanceof OutlineLayer) {
        this.detachOutlineLayer(layer);
      } else if (layer instanceof ConnectivityLayer) {
        layer.detach();
      }
    });

    // Dispose GPU compositor if present
    if (this.gpuCompositor) {
      this.gpuCompositor.dispose();
      this.gpuCompositor = null;
    }
    
    if (this.layerStack) {
      this.layerStack.dispose();
      this.layerStack = null as any;
    }
    
    this.compositeBuffer = null as any;
    
    // Call parent dispose
    super.dispose();
  }
}
