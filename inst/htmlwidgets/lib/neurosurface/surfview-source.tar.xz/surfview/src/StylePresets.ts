import type * as THREE from 'three';

export type SurfViewStylePresetName =
  | 'freesurfer'
  | 'default'
  | 'presentation'
  | 'paper-light'
  | 'report'
  | 'talk-dark'
  | 'clinical-qc'
  | 'retinotopy'
  | 'glass-brain-surface';

export type LabelDensity = 'none' | 'sparse' | 'normal' | 'dense';

export interface StylePresetBackground {
  css: string;
  clearColor: number;
  clearAlpha: number;
}

export interface StylePresetLighting {
  ambientColor: number;
  ambientIntensity: number;
  directionalColor: number;
  directionalIntensity: number;
  directionalPosition: [number, number, number];
  rimStrength: number;
  ssaoRadius: number;
  ssaoKernelSize: number;
  /** Fill light intensity (default 0.45). */
  fillIntensity?: number;
  /** Fragment shading of CPU-composited surfaces. */
  silhouetteDarkening?: number;
  thresholdOutline?: number;
  thresholdOutlineShade?: number;
  overlayEmission?: number;
}

export interface StylePresetMaterial {
  baseColor: THREE.ColorRepresentation;
  materialType: 'phong' | 'standard' | 'physical';
  metalness: number;
  roughness: number;
  alpha: number;
}

export interface StylePresetCurvature {
  brightness: number;
  contrast: number;
  smoothness: number;
}

export interface StylePresetROI {
  strokeColor: string;
  strokeWidth: number;
  labelDensity: LabelDensity;
  labelColor: string;
  labelFont: string;
}

export interface StylePresetAnnotation {
  radius: number;
  colorOn: number;
  colorOff: number;
  style: 'marker' | 'pin' | 'minimal';
}

export interface StylePresetColormaps {
  sequential: string;
  diverging: string;
  cyclic?: string;
  label?: string;
  curvature?: string;
}

export interface StylePresetFigure {
  width: number;
  height: number;
  dpi: number;
  transparent: boolean;
  colorbar: boolean;
  roiLabels: boolean;
  scaleBar: boolean;
  fontScale: number;
}

export interface SurfViewStylePreset {
  name: SurfViewStylePresetName;
  label: string;
  background: StylePresetBackground;
  lighting: StylePresetLighting;
  material: StylePresetMaterial;
  curvature: StylePresetCurvature;
  roi: StylePresetROI;
  annotation: StylePresetAnnotation;
  colormaps: StylePresetColormaps;
  figure: StylePresetFigure;
  labelDensity: LabelDensity;
  fontScale: number;
}

export interface FigureExportLabel {
  text: string;
  x: number;
  y: number;
  color?: string;
  background?: string;
  normalized?: boolean;
}

/**
 * Figure background: `'viewer'` reproduces the live viewer background (opaque
 * unless the viewer canvas itself is transparent), `'transparent'` exports
 * with alpha, and a number is an opaque 0xRRGGBB colour.
 */
export type FigureBackground = 'viewer' | 'transparent' | number;

/** Upper/lower cap markers: drawn values extend beyond the colour scale. */
export interface FigureColorbarCaps {
  low: boolean;
  high: boolean;
}

/** What a figure's colour key describes, typically taken from a data layer. */
export interface FigureColorbarSource {
  readonly label: string;
  /** CSS colours from the low to the high end of `range`. */
  readonly colors: readonly string[];
  readonly range: readonly [number, number];
  /** Masked interval: values inside it are not drawn. */
  readonly threshold?: readonly [number, number];
  readonly caps?: Readonly<FigureColorbarCaps>;
}

/** Live state the exporting viewer supplies to option resolution. */
export interface FigureExportContext {
  readonly background?: { readonly color: number; readonly transparent: boolean };
  readonly colorbar?: FigureColorbarSource | null;
}

export interface FigureExportOptions {
  preset?: SurfViewStylePresetName | SurfViewStylePreset;
  width?: number;
  height?: number;
  dpi?: number;
  /**
   * Explicit background; overrides `transparent` and `backgroundColor`. When
   * omitted, `transparent` falls back to the preset's figure default and the
   * colour to the live viewer background.
   */
  background?: FigureBackground;
  transparent?: boolean;
  colorbar?: boolean;
  /** Layer whose colormap, range, threshold and caps the colour key shows (default: the active layer). */
  colorbarLayer?: string;
  colorbarLabel?: string;
  colorbarRange?: [number, number];
  colorbarColors?: string[];
  /** Masked interval drawn as a hatched band on the key; null hides the band. */
  colorbarThreshold?: [number, number] | null;
  colorbarCaps?: Partial<FigureColorbarCaps>;
  roiLabels?: boolean | FigureExportLabel[];
  scaleBar?: boolean;
  scaleBarLabel?: string;
  scaleBarLength?: number;
  fontScale?: number;
  backgroundColor?: number;
  title?: string;
  subtitle?: string;
  downloadFilename?: string;
}

export interface ResolvedFigureExportOptions {
  width: number;
  height: number;
  dpi: number;
  transparent: boolean;
  colorbar: boolean;
  colorbarLabel: string;
  colorbarRange?: [number, number];
  colorbarColors: string[];
  colorbarThreshold?: [number, number];
  colorbarCaps: FigureColorbarCaps;
  roiLabels: boolean | FigureExportLabel[];
  scaleBar: boolean;
  scaleBarLabel: string;
  scaleBarLength: number;
  fontScale: number;
  backgroundColor: number;
  title?: string;
  subtitle?: string;
  downloadFilename?: string;
  preset: SurfViewStylePreset;
}

/*
 * Light levels. three.js lights are physically based: a Lambertian surface lit
 * head-on returns albedo × irradiance / π. With the default camera-attached
 * key (≈17° off axis, cos 0.956) and fill (≈31° off axis, cos 0.854),
 * ambient + 0.956·key + 0.854·fill ≈ π (ambient weighted by the luminance of
 * its colour) gives a camera-facing surface its full layer colour, so curvature greys and colormap
 * colours read at their nominal values; slopes then shade from the key light.
 * Presets differ in that balance (more ambient: flatter; more key: more
 * relief), not in overall exposure.
 */
const defaultLighting: StylePresetLighting = {
  ambientColor: 0xffffff,
  ambientIntensity: 1.0,
  directionalColor: 0xffffff,
  directionalIntensity: 1.84,
  directionalPosition: [1, 1, 1],
  rimStrength: 0,
  ssaoRadius: 4,
  ssaoKernelSize: 32,
  fillIntensity: 0.45
};

const defaultFigure: StylePresetFigure = {
  width: 1800,
  height: 1350,
  dpi: 300,
  transparent: false,
  colorbar: false,
  roiLabels: false,
  scaleBar: false,
  fontScale: 1
};

export const STYLE_PRESETS: Record<SurfViewStylePresetName, SurfViewStylePreset> = {
  freesurfer: {
    name: 'freesurfer',
    label: 'Cortical Contrast',
    background: { css: '#000000', clearColor: 0x000000, clearAlpha: 1 },
    lighting: {
      ambientColor: 0xffffff, ambientIntensity: 0.8,
      directionalColor: 0xffffff, directionalIntensity: 2.18,
      directionalPosition: [1, 1.25, 1.4],
      rimStrength: 0, ssaoRadius: 4, ssaoKernelSize: 32,
      fillIntensity: 0.3
    },
    material: {
      baseColor: 0xffffff, materialType: 'phong',
      metalness: 0, roughness: 1, alpha: 1
    },
    // Near-binary, freeview-like folding: |normalised curvature| ≥ 0.1 saturates.
    curvature: { brightness: 0.5, contrast: 0.5, smoothness: 0.2 },
    roi: {
      strokeColor: '#ffffff', strokeWidth: 1.8, labelDensity: 'sparse',
      labelColor: '#ffffff', labelFont: '11px sans-serif'
    },
    annotation: { radius: 0.72, colorOn: 0x00ff00, colorOff: 0xff0000, style: 'minimal' },
    colormaps: { sequential: 'surface-heat-positive', diverging: 'surface-heat', label: 'glasbey', curvature: 'gray' },
    figure: { ...defaultFigure },
    labelDensity: 'sparse', fontScale: 1
  },
  default: {
    name: 'default',
    label: 'Default',
    background: { css: '#000000', clearColor: 0x000000, clearAlpha: 1 },
    lighting: defaultLighting,
    material: {
      baseColor: 0xcccccc,
      materialType: 'phong',
      metalness: 0.1,
      roughness: 0.6,
      alpha: 1
    },
    curvature: { brightness: 0.55, contrast: 0.4, smoothness: 0.5 },
    roi: {
      strokeColor: '#ffd166',
      strokeWidth: 2,
      labelDensity: 'normal',
      labelColor: '#111827',
      labelFont: '12px sans-serif'
    },
    annotation: { radius: 0.75, colorOn: 0x00ff00, colorOff: 0xff0000, style: 'marker' },
    colormaps: { sequential: 'viridis', diverging: 'RdBu', label: 'glasbey', curvature: 'gray' },
    figure: defaultFigure,
    labelDensity: 'normal',
    fontScale: 1
  },
  presentation: {
    name: 'presentation',
    label: 'Presentation',
    background: {
      css: 'linear-gradient(135deg, #f7f7f9 0%, #e3e7ed 100%)',
      clearColor: 0x000000,
      clearAlpha: 0
    },
    lighting: {
      ambientColor: 0xffffff,
      ambientIntensity: 1.0,
      directionalColor: 0xffffff,
      directionalIntensity: 1.84,
      directionalPosition: [1.5, 1.2, 1],
      rimStrength: 0.35,
      ssaoRadius: 6,
      ssaoKernelSize: 32,
      fillIntensity: 0.45,
      // A quarter of each overlay colour is emitted rather than lit, so
      // colormap hues stay saturated on slopes facing away from the key.
      overlayEmission: 0.25
    },
    material: {
      baseColor: 0xd0d4dc,
      materialType: 'physical',
      metalness: 0.05,
      roughness: 0.35,
      alpha: 1
    },
    curvature: { brightness: 0.58, contrast: 0.38, smoothness: 0.5 },
    roi: {
      strokeColor: '#f59e0b',
      strokeWidth: 2.5,
      labelDensity: 'normal',
      labelColor: '#111827',
      labelFont: '13px sans-serif'
    },
    annotation: { radius: 0.9, colorOn: 0x0ea5e9, colorOff: 0xef4444, style: 'pin' },
    colormaps: { sequential: 'viridis', diverging: 'RdBu', label: 'glasbey', curvature: 'gray' },
    figure: { ...defaultFigure, width: 1920, height: 1080, colorbar: true, fontScale: 1.15 },
    labelDensity: 'normal',
    fontScale: 1.15
  },
  'paper-light': {
    name: 'paper-light',
    label: 'Paper Light',
    background: { css: '#ffffff', clearColor: 0xffffff, clearAlpha: 1 },
    lighting: {
      ambientColor: 0xffffff,
      ambientIntensity: 1.1,
      directionalColor: 0xffffff,
      directionalIntensity: 1.78,
      directionalPosition: [1, 1.25, 1.4],
      fillIntensity: 0.4,
      rimStrength: 0.12,
      ssaoRadius: 4,
      ssaoKernelSize: 32
    },
    material: {
      baseColor: 0xd8dbe0,
      materialType: 'standard',
      metalness: 0,
      roughness: 0.72,
      alpha: 1
    },
    curvature: { brightness: 0.62, contrast: 0.32, smoothness: 0.5 },
    roi: {
      strokeColor: '#111827',
      strokeWidth: 1.8,
      labelDensity: 'sparse',
      labelColor: '#111827',
      labelFont: '11px sans-serif'
    },
    annotation: { radius: 0.72, colorOn: 0x0f766e, colorOff: 0xb91c1c, style: 'minimal' },
    colormaps: { sequential: 'viridis', diverging: 'RdBu', label: 'glasbey', curvature: 'gray' },
    figure: { width: 2400, height: 1800, dpi: 300, transparent: true, colorbar: true, roiLabels: true, scaleBar: true, fontScale: 1 },
    labelDensity: 'sparse',
    fontScale: 1
  },
  report: {
    name: 'report',
    label: 'Report',
    // Interactive report widgets: a quiet two-tone sulcal underlay under a
    // camera-attached key light, on a neutral panel grey that separates the
    // cortex from white report pages.
    background: { css: '#f3f5f5', clearColor: 0xf3f5f5, clearAlpha: 1 },
    lighting: {
      ambientColor: 0xffffff,
      ambientIntensity: 1.0,
      directionalColor: 0xffffff,
      directionalIntensity: 1.88,
      directionalPosition: [1, 1.25, 1.4],
      rimStrength: 0,
      ssaoRadius: 4,
      ssaoKernelSize: 32,
      fillIntensity: 0.4,
      silhouetteDarkening: 0.2,
      thresholdOutline: 1,
      thresholdOutlineShade: 0.55,
      overlayEmission: 0.4
    },
    material: {
      baseColor: 0xffffff,
      materialType: 'phong',
      metalness: 0,
      roughness: 0.85,
      alpha: 1
    },
    curvature: { brightness: 0.73, contrast: 0.32, smoothness: 0.2 },
    roi: {
      strokeColor: '#1b2427',
      strokeWidth: 1.8,
      labelDensity: 'sparse',
      labelColor: '#1b2427',
      labelFont: '11px sans-serif'
    },
    annotation: { radius: 0.72, colorOn: 0x2f6f73, colorOff: 0xb91c1c, style: 'minimal' },
    colormaps: {
      sequential: 'surface-heat-positive',
      diverging: 'surface-heat',
      label: 'glasbey',
      curvature: 'gray'
    },
    // Opaque on the viewer's own panel grey: report figures sit on slides and
    // pages next to the static figures, not over arbitrary backgrounds.
    figure: { width: 2400, height: 1800, dpi: 300, transparent: false, colorbar: true, roiLabels: true, scaleBar: true, fontScale: 1 },
    labelDensity: 'sparse',
    fontScale: 1
  },
  'talk-dark': {
    name: 'talk-dark',
    label: 'Talk Dark',
    background: { css: '#0b0f14', clearColor: 0x0b0f14, clearAlpha: 1 },
    lighting: {
      // Faintly cool ambient against the dark slide background.
      ambientColor: 0xdde4f0,
      ambientIntensity: 0.9,
      directionalColor: 0xffffff,
      directionalIntensity: 2.24,
      directionalPosition: [1.2, 1.1, 0.9],
      fillIntensity: 0.35,
      rimStrength: 0.55,
      ssaoRadius: 6,
      ssaoKernelSize: 32
    },
    material: {
      baseColor: 0x9aa6b2,
      materialType: 'physical',
      metalness: 0.02,
      roughness: 0.42,
      alpha: 1
    },
    curvature: { brightness: 0.5, contrast: 0.46, smoothness: 0.5 },
    roi: {
      strokeColor: '#fbbf24',
      strokeWidth: 3,
      labelDensity: 'normal',
      labelColor: '#f8fafc',
      labelFont: '13px sans-serif'
    },
    annotation: { radius: 1.05, colorOn: 0x38bdf8, colorOff: 0xfb7185, style: 'pin' },
    colormaps: { sequential: 'magma', diverging: 'RdBu', label: 'glasbey', curvature: 'gray' },
    figure: { width: 1920, height: 1080, dpi: 150, transparent: false, colorbar: true, roiLabels: true, scaleBar: true, fontScale: 1.25 },
    labelDensity: 'normal',
    fontScale: 1.25
  },
  'clinical-qc': {
    name: 'clinical-qc',
    label: 'Clinical QC',
    background: { css: '#f3f4f6', clearColor: 0xf3f4f6, clearAlpha: 1 },
    lighting: {
      ambientColor: 0xffffff,
      ambientIntensity: 1.05,
      directionalColor: 0xffffff,
      directionalIntensity: 1.79,
      directionalPosition: [0.8, 1.4, 1.1],
      fillIntensity: 0.45,
      rimStrength: 0.2,
      ssaoRadius: 3,
      ssaoKernelSize: 16
    },
    material: {
      baseColor: 0xcbd5e1,
      materialType: 'standard',
      metalness: 0,
      roughness: 0.78,
      alpha: 1
    },
    curvature: { brightness: 0.55, contrast: 0.42, smoothness: 0.5 },
    roi: {
      strokeColor: '#dc2626',
      strokeWidth: 2.2,
      labelDensity: 'dense',
      labelColor: '#111827',
      labelFont: '12px sans-serif'
    },
    annotation: { radius: 0.8, colorOn: 0x2563eb, colorOff: 0xdc2626, style: 'marker' },
    colormaps: { sequential: 'viridis', diverging: 'RdBu', label: 'glasbey', curvature: 'gray' },
    figure: { width: 1800, height: 1200, dpi: 200, transparent: false, colorbar: true, roiLabels: true, scaleBar: true, fontScale: 1 },
    labelDensity: 'dense',
    fontScale: 1
  },
  retinotopy: {
    name: 'retinotopy',
    label: 'Retinotopy',
    background: { css: '#111111', clearColor: 0x111111, clearAlpha: 1 },
    lighting: {
      ambientColor: 0xffffff,
      ambientIntensity: 1.0,
      directionalColor: 0xffffff,
      directionalIntensity: 1.84,
      directionalPosition: [1, 1, 1.3],
      fillIntensity: 0.45,
      rimStrength: 0.28,
      ssaoRadius: 4,
      ssaoKernelSize: 32
    },
    material: {
      baseColor: 0xb8bec8,
      materialType: 'standard',
      metalness: 0,
      roughness: 0.58,
      alpha: 1
    },
    // Darker, high-contrast folding under saturated phase/eccentricity maps.
    curvature: { brightness: 0.45, contrast: 0.5, smoothness: 0.4 },
    roi: {
      strokeColor: '#ffffff',
      strokeWidth: 2,
      labelDensity: 'dense',
      labelColor: '#ffffff',
      labelFont: '12px sans-serif'
    },
    annotation: { radius: 0.85, colorOn: 0xffffff, colorOff: 0x94a3b8, style: 'minimal' },
    colormaps: { sequential: 'hsv', diverging: 'RdBu', cyclic: 'hsv', label: 'glasbey', curvature: 'gray' },
    figure: { width: 2200, height: 1600, dpi: 300, transparent: false, colorbar: true, roiLabels: true, scaleBar: false, fontScale: 1.05 },
    labelDensity: 'dense',
    fontScale: 1.05
  },
  'glass-brain-surface': {
    name: 'glass-brain-surface',
    label: 'Glass Surface',
    background: { css: '#f8fafc', clearColor: 0xf8fafc, clearAlpha: 1 },
    lighting: {
      ambientColor: 0xe6efff,
      ambientIntensity: 1.0,
      directionalColor: 0xffffff,
      directionalIntensity: 1.99,
      directionalPosition: [1.4, 1.1, 1.2],
      fillIntensity: 0.45,
      rimStrength: 0.45,
      ssaoRadius: 5,
      ssaoKernelSize: 32
    },
    material: {
      baseColor: 0xdbeafe,
      materialType: 'physical',
      metalness: 0,
      roughness: 0.18,
      alpha: 0.62
    },
    curvature: { brightness: 0.62, contrast: 0.26, smoothness: 0.6 },
    roi: {
      strokeColor: '#2563eb',
      strokeWidth: 2.4,
      labelDensity: 'sparse',
      labelColor: '#0f172a',
      labelFont: '12px sans-serif'
    },
    annotation: { radius: 0.8, colorOn: 0x2563eb, colorOff: 0x64748b, style: 'pin' },
    colormaps: { sequential: 'viridis', diverging: 'RdBu', label: 'glasbey', curvature: 'gray' },
    figure: { width: 2200, height: 1500, dpi: 300, transparent: true, colorbar: true, roiLabels: true, scaleBar: true, fontScale: 1.05 },
    labelDensity: 'sparse',
    fontScale: 1.05
  }
};

export function listStylePresets(): SurfViewStylePresetName[] {
  return Object.keys(STYLE_PRESETS) as SurfViewStylePresetName[];
}

export function getStylePreset(name: SurfViewStylePresetName): SurfViewStylePreset {
  return cloneStylePreset(STYLE_PRESETS[name]);
}

export function resolveStylePreset(preset: SurfViewStylePresetName | SurfViewStylePreset | undefined): SurfViewStylePreset {
  if (!preset) return getStylePreset('default');
  if (typeof preset === 'string') {
    const style = STYLE_PRESETS[preset];
    if (!style) {
      throw new Error(`Unknown SurfView style preset: ${preset}`);
    }
    return cloneStylePreset(style);
  }
  return cloneStylePreset(preset);
}

/**
 * Merge explicit export options, the exporting viewer's live state
 * (`context`) and the preset's figure defaults, in that order of precedence.
 */
export function resolveFigureExportOptions(
  presetOrName: SurfViewStylePresetName | SurfViewStylePreset | undefined,
  options: FigureExportOptions = {},
  fallbackSize: { width: number; height: number } = { width: defaultFigure.width, height: defaultFigure.height },
  context: FigureExportContext = {}
): ResolvedFigureExportOptions {
  const preset = resolveStylePreset(options.preset ?? presetOrName);
  const figure = preset.figure;
  const width = positiveInteger(options.width, figure.width || fallbackSize.width, 'width');
  const height = positiveInteger(options.height, figure.height || fallbackSize.height, 'height');
  const dpi = positiveInteger(options.dpi, figure.dpi, 'dpi');
  const fontScale = finitePositive(options.fontScale, figure.fontScale, 'fontScale');
  const { transparent, backgroundColor } = resolveFigureBackground(preset, options, context);
  const source = context.colorbar ?? null;
  // A context that reports `colorbar: null` means the viewer has no layer for
  // the key to describe; a preset default must not invent one (#12). Explicit
  // requests (`colorbar: true`, a range or colours) still draw a key.
  const noLayerToDescribe = 'colorbar' in context && context.colorbar === null &&
    options.colorbarRange === undefined && options.colorbarColors === undefined;
  const colorbarRange = options.colorbarRange ??
    (source ? [source.range[0], source.range[1]] as [number, number] : undefined);
  const colorbarThreshold = options.colorbarThreshold === null
    ? undefined
    : options.colorbarThreshold ??
      (source?.threshold ? [source.threshold[0], source.threshold[1]] as [number, number] : undefined);

  return {
    width,
    height,
    dpi,
    transparent,
    colorbar: options.colorbar ?? (noLayerToDescribe ? false : figure.colorbar),
    colorbarLabel: options.colorbarLabel ?? source?.label ?? 'Value',
    colorbarColors: options.colorbarColors ?? (source ? [...source.colors] : defaultColorbarColors(preset)),
    colorbarCaps: {
      low: options.colorbarCaps?.low ?? source?.caps?.low ?? false,
      high: options.colorbarCaps?.high ?? source?.caps?.high ?? false
    },
    roiLabels: options.roiLabels ?? figure.roiLabels,
    scaleBar: options.scaleBar ?? figure.scaleBar,
    scaleBarLabel: options.scaleBarLabel ?? '',
    scaleBarLength: finitePositive(options.scaleBarLength, 0.18, 'scaleBarLength'),
    fontScale,
    backgroundColor,
    preset,
    ...(colorbarRange === undefined ? {} : { colorbarRange }),
    ...(colorbarThreshold === undefined ? {} : { colorbarThreshold }),
    ...(options.title === undefined ? {} : { title: options.title }),
    ...(options.subtitle === undefined ? {} : { subtitle: options.subtitle }),
    ...(options.downloadFilename === undefined
      ? {}
      : { downloadFilename: options.downloadFilename })
  };
}

function resolveFigureBackground(
  preset: SurfViewStylePreset,
  options: FigureExportOptions,
  context: FigureExportContext
): { transparent: boolean; backgroundColor: number } {
  const viewerColor = context.background?.color ?? preset.background.clearColor;
  const background = options.background;
  if (background === 'transparent') return { transparent: true, backgroundColor: viewerColor };
  if (background === 'viewer') {
    return { transparent: context.background?.transparent ?? false, backgroundColor: viewerColor };
  }
  if (typeof background === 'number') {
    if (!Number.isInteger(background) || background < 0 || background > 0xffffff) {
      throw new RangeError('Figure export background must be an integer RGB value between 0x000000 and 0xffffff');
    }
    return { transparent: false, backgroundColor: background };
  }
  if (background !== undefined) {
    throw new TypeError("Figure export background must be 'viewer', 'transparent' or an RGB number");
  }
  return {
    transparent: options.transparent ?? preset.figure.transparent,
    backgroundColor: options.backgroundColor ?? viewerColor
  };
}

function defaultColorbarColors(preset: SurfViewStylePreset): string[] {
  if (preset.colormaps.diverging === 'RdBu') {
    return ['#2166ac', '#f7f7f7', '#b2182b'];
  }
  if (preset.colormaps.sequential === 'magma') {
    return ['#000004', '#b73779', '#fcfdbf'];
  }
  if (preset.colormaps.sequential === 'hsv' || preset.colormaps.cyclic === 'hsv') {
    return ['#ff0000', '#ffff00', '#00ffff', '#0000ff', '#ff00ff', '#ff0000'];
  }
  return ['#440154', '#21908c', '#fde725'];
}

function positiveInteger(value: number | undefined, fallback: number, label: string): number {
  const resolved = value ?? fallback;
  if (!Number.isFinite(resolved) || resolved <= 0) {
    throw new Error(`Figure export ${label} must be a positive number`);
  }
  return Math.round(resolved);
}

function finitePositive(value: number | undefined, fallback: number, label: string): number {
  const resolved = value ?? fallback;
  if (!Number.isFinite(resolved) || resolved <= 0) {
    throw new Error(`Figure export ${label} must be a positive number`);
  }
  return resolved;
}

function cloneStylePreset(preset: SurfViewStylePreset): SurfViewStylePreset {
  return {
    ...preset,
    background: { ...preset.background },
    lighting: {
      ...preset.lighting,
      directionalPosition: [...preset.lighting.directionalPosition]
    },
    material: { ...preset.material },
    curvature: { ...preset.curvature },
    roi: { ...preset.roi },
    annotation: { ...preset.annotation },
    colormaps: { ...preset.colormaps },
    figure: { ...preset.figure }
  };
}
