/**
 * Events emitted by surfaces
 */

import type { NeuroSurface } from '../classes';
import type { Layer } from '../layers';
import type { ColorRepresentation } from 'three';

export interface SurfaceLayerReorderedEvent {
  surface: NeuroSurface;
  order: readonly string[];
  previousOrder: readonly string[];
  movedLayerId?: string;
}

export interface SurfaceEventMap {
  'visibility:changed': { surface: NeuroSurface; visible: boolean };
  'opacity:changed': { surface: NeuroSurface; opacity: number };
  'color:changed': { surface: NeuroSurface; color: ColorRepresentation };
  'layer:added': { surface: NeuroSurface; layer: Layer };
  'layer:removed': { surface: NeuroSurface; layerId: string };
  'layer:updated': { surface: NeuroSurface; layer?: Layer | null; changes?: Record<string, unknown> };
  'layer:reordered': SurfaceLayerReorderedEvent;
  'data:updated': { surface: NeuroSurface; data: Float32Array };
  'geometry:updated': { surface: NeuroSurface };
  'geometry:smoothed': { surface: NeuroSurface; iterations: number; lambda: number; method: string };
  'variant:changed': { surface: NeuroSurface; variant: string };
  /**
   * Each frame of an animated variant switch: `progress` is the time fraction
   * in [0, 1] (as `morph:animating`), `weight` the eased shape fraction (0 =
   * the shape the switch started from, 1 = `variant`).
   */
  'variant:animating': { surface: NeuroSurface; variant: string; progress: number; weight: number };
  'material:updated': { surface: NeuroSurface };
  'morph:changed': { surface: NeuroSurface; target?: string; weight?: number; weights?: Record<string, number> };
  'morph:animating': { surface: NeuroSurface; progress: number };
  'morph:complete': { surface: NeuroSurface; target?: string; weights?: Record<string, number> };
  'morph:cancelled': { surface: NeuroSurface };
  'dispose': { surface: NeuroSurface };
  'render:needed': { surface: NeuroSurface };
}

export type SurfaceEventType = keyof SurfaceEventMap;
