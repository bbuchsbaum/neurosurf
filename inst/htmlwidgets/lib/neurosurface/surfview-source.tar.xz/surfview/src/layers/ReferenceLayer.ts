import { RGBALayer } from '../layers';
import type { LayerConfig } from '../layers';

/** Full binary vertex membership, rendered categorically at fragment level. */
export class ReferenceLayer extends RGBALayer {
  constructor(id: string, readonly membership: Float32Array,
              readonly color: readonly number[], config: LayerConfig) {
    super(id, new Float32Array(membership.length * 4), config);
    if (membership.some(value => value !== 0 && value !== 1)) {
      throw new Error('Reference membership must be finite and binary');
    }
  }
}
