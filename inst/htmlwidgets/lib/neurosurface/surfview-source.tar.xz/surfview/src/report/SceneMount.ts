import { NeuroSurfaceViewer } from '../NeuroSurfaceViewer';
import { SurfaceGeometry } from '../classes';
import { MultiLayerNeuroSurface } from '../MultiLayerNeuroSurface';
import { ReferenceLayer } from '../layers/ReferenceLayer';
import { DataLayer } from '../layers';
import type { LayerPresentation } from '../layers';
import type { FigureExportOptions, SurfViewStylePresetName } from '../StylePresets';
import {
  ANATOMICAL_VIEWS,
  freezeBilateralSurfaceGroup
} from '../AnatomicalView';
import type {
  AnatomicalView,
  AnatomicalViewCapabilities,
  BilateralSurfaceGroup
} from '../AnatomicalView';
import type {
  SurfViewControlTarget
} from '../controls';
import {
  loadSceneAsset,
  sceneGeometryInitialVariant,
  validateSceneManifest
} from '../scene';
import type {
  SceneTypedArray,
  SurfViewSceneLayerManifest,
  SurfViewSceneManifest
} from '../scene';
import {
  ReportSceneController
} from './ReportSceneController';
import type {
  ReportBrainView,
  ReportFitInsets,
  ReportLayout,
  ReportObliqueAngle
} from './ReportSceneController';
import {
  createReportSceneControlTarget,
  ReportSceneControlTarget
} from './ReportSceneControlTarget';
import { ReportControls } from './ReportControls';

export {
  layoutReportAnatomicalBrain,
  layoutReportAnatomicalMeshes,
  REPORT_BRAIN_VIEWS,
  reportBrainViewAxes
} from './ReportSceneController';
export type {
  ReportAnatomicalMesh,
  ReportBrainView,
  ReportFitInsets,
  ReportLayout,
  ReportObliqueAngle
} from './ReportSceneController';

export type SurfViewSceneView = AnatomicalView | 'reset';

export interface MountSurfViewOptions {
  /** Delay asset loading and WebGL creation until the container intersects the viewport. */
  lazy?: boolean;
  /** IntersectionObserver root margin used by lazy mounting. */
  rootMargin?: string;
  /** Asset URL base for adjacent-directory manifests. */
  baseUrl?: string;
  /** Fetch implementation used for adjacent assets. */
  fetcher?: typeof fetch;
  /** Initial CSS-pixel width. Defaults to the container width or 640. */
  width?: number;
  /** Initial CSS-pixel height. Defaults to the container height or 480. */
  height?: number;
  /** Viewer appearance preset. `paper-light` is the report default. */
  preset?: SurfViewStylePresetName;
  /** Show the small report toolbar. This never loads an external pane UI. */
  controls?: boolean;
  /** Initial anatomical view. */
  initialView?: AnatomicalView;
  /**
   * Explicit pair controlled by coordinated report views. Required when a
   * report contains more than one surface; pairs are never inferred.
   */
  bilateralGroup?: BilateralSurfaceGroup;
  /** Gap between recentered hemispheres in scene units. */
  hemisphereGap?: number;
  /**
   * Pair pose: `split` (default) rotates each hemisphere into the view side by
   * side; `anatomical` keeps one coherent brain and rotates it as a whole.
   */
  layout?: ReportLayout;
  /** Initial whole-brain view for the anatomical layout. Defaults to `oblique`. */
  initialBrainView?: ReportBrainView;
  /** Attach the key light to the camera. Defaults to true for the anatomical layout. */
  headlight?: boolean;
  /** Vertical camera field of view in degrees. */
  fov?: number;
  /** Camera fit margin as a fraction of the framed distance. */
  fitMargin?: number;
  /** Camera angle of the `oblique` whole-brain view in degrees, or `auto` (data-driven). */
  oblique?: ReportObliqueAngle | 'auto';
  /** Canvas insets (CSS px) kept clear of the fitted brain for overlaid controls. */
  fitInsets?: ReportFitInsets;
  /** Called after a load or WebGL initialization failure is rendered inline. */
  onError?: (error: Error) => void;
}

export interface SurfViewMountHandle {
  /** Resolves after assets, surfaces, controls, and the first view are ready. */
  readonly ready: Promise<void>;
  /** The viewer after mounting, or null while lazy/unmounted/disposed. */
  readonly viewer: NeuroSurfaceViewer | null;
  /** The report-aware target after mounting, or null while lazy/unmounted/disposed. */
  readonly controlTarget: SurfViewControlTarget | null;
  /** The validated manifest used by this mount. */
  readonly manifest: SurfViewSceneManifest;
  selectLayer(layerId: string): void;
  /** @deprecated Passing "reset" remains supported; prefer resetView(). */
  setView(view: SurfViewSceneView): void;
  /** Restore the initial anatomical view and authored reference visibility/opacity. */
  resetView(): void;
  /** Pose the pair as one brain (anatomical layout only). */
  setBrainView(view: ReportBrainView): void;
  /** Current whole-brain view, or null after free rotation. */
  getBrainView(): ReportBrainView | null;
  /** Update the canvas insets kept clear of the fitted brain, and refit. */
  setFitInsets(insets: ReportFitInsets): void;
  getAnatomicalViewCapabilities(): AnatomicalViewCapabilities;
  /**
   * Names of the alternative surface embeddings the scene ships (for example
   * inflated, pial, white), in manifest order; empty without variants.
   */
  getSurfaceVariants(): readonly string[];
  /** The embedding currently shown, or null when the scene has no variants. */
  getSurfaceVariant(): string | null;
  /**
   * Show another embedding on every hemisphere. Data, threshold, curvature and
   * the current view are kept; a named view is re-posed and refitted.
   */
  setSurfaceVariant(name: string): void;
  resize(width?: number, height?: number): void;
  exportPNG(options?: FigureExportOptions): string;
  dispose(): void;
}

interface LoadedSurface {
  id: string;
  hemisphere: 'left' | 'right';
  surface: MultiLayerNeuroSurface;
}

function abortError(message: string): DOMException {
  return new DOMException(message, 'AbortError');
}

function asError(error: unknown): Error {
  return error instanceof Error ? error : new Error(String(error));
}

function finiteSize(value: number | undefined, fallback: number): number {
  return value !== undefined && Number.isFinite(value) && value > 0
    ? value
    : fallback;
}

/**
 * Builds the scalar layer a report mount shows for one manifest layer on one
 * geometry. The manifest's presentation travels with the layer, so figure
 * export and `getFigureColorbarSource()` label the colour key with the legend
 * title (or label) and units, the same names the report control target shows.
 *
 * @param manifest - Manifest layer entry.
 * @param values - Decoded per-vertex (or per-index) values for this geometry.
 * @param indices - Optional vertex indices for sparse values.
 * @param visible - Whether the layer starts visible.
 */
export function createSceneDataLayer(
  manifest: SurfViewSceneLayerManifest,
  values: Float32Array,
  indices: Uint32Array | null,
  visible: boolean
): DataLayer {
  if (manifest.role === 'reference') throw new TypeError('A reference is not a quantitative map');
  const label = manifest.legend?.title ?? manifest.label;
  const units = manifest.legend?.units ?? manifest.units;
  const presentation: Partial<LayerPresentation> = {
    ...(label === undefined ? {} : { label }),
    ...(units === undefined ? {} : { units }),
    ...(manifest.provenance === undefined ? {} : { provenance: manifest.provenance })
  };
  return new DataLayer(
    manifest.id,
    values,
    indices,
    manifest.colorMap,
    {
      range: manifest.limits,
      opacity: manifest.opacity ?? 1,
      visible,
      presentation,
      ...(manifest.threshold === undefined ? {} : { threshold: manifest.threshold }),
      ...(manifest.magnitudeOpacity === undefined ? {} : { magnitudeOpacity: manifest.magnitudeOpacity })
    }
  );
}

class SceneMount implements SurfViewMountHandle {
  readonly ready: Promise<void>;
  readonly manifest: SurfViewSceneManifest;

  private readonly container: HTMLElement;
  private readonly options: Required<Pick<MountSurfViewOptions,
    'lazy' | 'rootMargin' | 'preset' | 'controls' | 'initialView' | 'hemisphereGap'>> &
    MountSurfViewOptions;
  private readonly abortController = new AbortController();
  private readonly root: HTMLDivElement;
  private readonly stage: HTMLDivElement;
  private readonly status: HTMLDivElement;
  private readonly surfaces: LoadedSurface[] = [];
  private observer: IntersectionObserver | null = null;
  private resizeObserver: ResizeObserver | null = null;
  private reportControls: ReportControls | null = null;
  private currentViewer: NeuroSurfaceViewer | null = null;
  private reportController: ReportSceneController | null = null;
  private reportTarget: ReportSceneControlTarget | null = null;
  private mounted = false;
  private mounting = false;
  private disposed = false;
  private selectedLayer: string;
  private selectedView: AnatomicalView;
  private selectedBrainView: ReportBrainView | null = null;
  private viewGroup: BilateralSurfaceGroup | null = null;
  private readonly variantNames: readonly string[];
  private selectedVariant: string | null;
  /** Per surface id: variant name -> owned copy of its vertex positions. */
  private readonly variantPositions = new Map<string, Map<string, Float32Array>>();
  private resolveReady!: () => void;
  private rejectReady!: (error: Error) => void;

  constructor(
    container: HTMLElement,
    manifest: SurfViewSceneManifest,
    options: MountSurfViewOptions
  ) {
    this.container = container;
    this.manifest = manifest;
    const { bilateralGroup, ...optionValues } = options;
    this.options = {
      ...optionValues,
      lazy: options.lazy ?? true,
      rootMargin: options.rootMargin ?? '128px',
      preset: options.preset ?? 'paper-light',
      controls: options.controls ?? true,
      initialView: options.initialView ?? 'lateral',
      hemisphereGap: options.hemisphereGap ?? 8,
      ...(bilateralGroup === undefined
        ? {}
        : { bilateralGroup: freezeBilateralSurfaceGroup(bilateralGroup) })
    };
    this.selectedLayer = manifest.selectedLayer ??
      Object.values(manifest.layers).find(layer => layer.role !== 'reference' && layer.visible)?.id ??
      Object.values(manifest.layers).find(layer => layer.role !== 'reference')?.id ?? '';
    this.selectedView = this.options.initialView;
    const firstGeometry = Object.values(manifest.geometries)[0];
    this.variantNames = Object.freeze(Object.keys(firstGeometry?.variants ?? {}));
    this.selectedVariant = firstGeometry ? sceneGeometryInitialVariant(firstGeometry) : null;

    this.ready = new Promise<void>((resolve, reject) => {
      this.resolveReady = resolve;
      this.rejectReady = reject;
    });

    this.root = document.createElement('div');
    this.root.className = 'surfview-mount';
    this.root.dataset.sceneId = manifest.id;
    this.root.style.position = 'relative';
    this.root.style.width = '100%';

    this.stage = document.createElement('div');
    this.stage.className = 'surfview-stage';
    this.stage.style.minHeight = `${finiteSize(options.height, 480)}px`;
    this.stage.style.position = 'relative';
    this.stage.style.width = '100%';

    this.status = document.createElement('div');
    this.status.className = 'surfview-status';
    this.status.setAttribute('role', 'status');
    this.status.textContent = this.options.lazy
      ? 'Surface view will load when visible.'
      : 'Loading surface view…';
    Object.assign(this.status.style, {
      alignItems: 'center',
      background: '#f8fafc',
      color: '#475569',
      display: 'flex',
      font: '13px/1.5 system-ui, sans-serif',
      inset: '0',
      justifyContent: 'center',
      padding: '1rem',
      position: 'absolute',
      textAlign: 'center'
    });
    this.stage.appendChild(this.status);
    this.root.appendChild(this.stage);
    container.appendChild(this.root);

    if (typeof ResizeObserver !== 'undefined') {
      this.resizeObserver = new ResizeObserver(entries => {
        const rect = entries[0]?.contentRect;
        if (rect?.width && this.currentViewer) {
          // Follow the container's own height when it has one (a CSS-sized
          // frame); the stage's min-height only remembers the previous size.
          this.resize(
            rect.width,
            this.options.height ?? finiteSize(
              rect.height,
              finiteSize(this.stage.getBoundingClientRect().height, 480)
            )
          );
        }
      });
      this.resizeObserver.observe(container);
    }

    if (this.options.lazy && typeof IntersectionObserver !== 'undefined') {
      this.observer = new IntersectionObserver(entries => {
        if (entries.some(entry => entry.isIntersecting)) {
          this.observer?.disconnect();
          this.observer = null;
          void this.mount();
        }
      }, { rootMargin: this.options.rootMargin });
      this.observer.observe(this.root);
    } else {
      void this.mount();
    }
  }

  get viewer(): NeuroSurfaceViewer | null {
    return this.currentViewer;
  }

  get controlTarget(): SurfViewControlTarget | null {
    return this.reportTarget;
  }

  selectLayer(layerId: string): void {
    const layer = this.manifest.layers[layerId];
    if (!layer) throw new Error(`Unknown scene layer: ${layerId}`);
    if (layer.role === 'reference') throw new Error('A reference cannot be selected as a quantitative map');
    this.selectedLayer = layerId;
    if (!this.mounted || !this.reportTarget) return;
    const result = this.reportTarget.setDisplayedLayer(layerId);
    if (!result.ok) {
      throw new Error(result.message);
    }
  }

  setView(view: SurfViewSceneView): void {
    if (view === 'reset') {
      this.resetView();
      return;
    }
    this.selectedView = view;
    if (!this.mounted || !this.reportTarget || !this.reportController) return;
    const target = this.reportController.getViewTarget();
    if (!target) {
      throw new Error('Multiple report surfaces require an explicit bilateralGroup option');
    }
    const result = this.reportTarget.setAnatomicalView({
      view,
      target,
      fit: true
    });
    if (!result.ok) throw new Error(result.message);
  }

  resetView(): void {
    if (this.options.layout === 'anatomical') {
      this.selectedBrainView = this.options.initialBrainView ?? 'oblique';
      if (!this.mounted || !this.reportController) return;
      const result = this.reportController.resetView();
      if (!result.ok) throw new Error(result.message);
      return;
    }
    this.selectedView = this.options.initialView;
    if (!this.mounted || !this.reportTarget) return;
    const result = this.reportTarget.resetView();
    if (!result.ok) throw new Error(result.message);
  }

  setBrainView(view: ReportBrainView): void {
    this.selectedBrainView = view;
    if (!this.mounted || !this.reportController) return;
    const result = this.reportController.setBrainView(view, { fit: true });
    if (!result.ok) throw new Error(result.message);
  }

  getBrainView(): ReportBrainView | null {
    return this.reportController?.getBrainView() ?? null;
  }

  setFitInsets(insets: ReportFitInsets): void {
    this.options.fitInsets = insets;
    this.reportController?.setFitInsets(insets);
    this.currentViewer?.requestRender();
  }

  getAnatomicalViewCapabilities(): AnatomicalViewCapabilities {
    if (this.currentViewer) return this.currentViewer.getAnatomicalViewCapabilities();
    const surfaceIds = Object.keys(this.manifest.geometries).sort();
    return Object.freeze({
      views: ANATOMICAL_VIEWS,
      singleSurfaceIds: Object.freeze(surfaceIds),
      bilateralGroups: Object.freeze(
        this.options.bilateralGroup ? [this.options.bilateralGroup] : []
      )
    });
  }

  getSurfaceVariants(): readonly string[] {
    return this.variantNames;
  }

  getSurfaceVariant(): string | null {
    return this.selectedVariant;
  }

  setSurfaceVariant(name: string): void {
    if (!this.variantNames.includes(name)) {
      throw new Error(`Unknown surface variant: ${name}`);
    }
    if (name === this.selectedVariant) return;
    this.selectedVariant = name;
    if (!this.mounted) return;
    this.applySurfaceVariant(name);
    if (this.reportController) {
      const result = this.reportController.refreshGeometry();
      if (!result.ok) throw new Error(result.message);
    }
    this.currentViewer?.requestRender();
  }

  /** Swap every surface's vertex positions to `name`, as VariantSurface does. */
  private applySurfaceVariant(name: string): void {
    for (const { id, surface } of this.surfaces) {
      const target = this.variantPositions.get(id)?.get(name);
      const geometry = surface.mesh?.geometry;
      const position = geometry?.getAttribute('position');
      if (!target || !geometry || !position) continue;
      (position.array as Float32Array).set(target);
      position.needsUpdate = true;
      geometry.computeVertexNormals();
      geometry.computeBoundingBox();
      geometry.computeBoundingSphere();
      surface.geometry.vertices.set(target);
      surface.geometry.invalidateBounds?.();
      surface.emit('geometry:updated', { surface });
    }
  }

  resize(width?: number, height?: number): void {
    const measured = this.container.getBoundingClientRect();
    const nextWidth = finiteSize(width, finiteSize(measured.width, this.options.width ?? 640));
    const nextHeight = finiteSize(height, finiteSize(measured.height, this.options.height ?? 480));
    this.stage.style.minHeight = `${nextHeight}px`;
    if (this.currentViewer) {
      this.currentViewer.resize(nextWidth, nextHeight);
      this.reportController?.resizeFit();
    }
  }

  exportPNG(options: FigureExportOptions = {}): string {
    if (!this.currentViewer || !this.mounted) {
      throw new Error('Surface view is not mounted');
    }
    return this.currentViewer.exportPNG(options);
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    this.abortController.abort();
    this.observer?.disconnect();
    this.observer = null;
    this.resizeObserver?.disconnect();
    this.resizeObserver = null;
    this.reportControls?.dispose();
    this.reportControls = null;
    this.reportTarget?.dispose();
    this.reportTarget = null;
    this.reportController?.dispose();
    this.reportController = null;
    this.currentViewer?.dispose();
    this.currentViewer = null;
    this.surfaces.length = 0;
    this.root.remove();
    if (!this.mounted) {
      this.rejectReady(abortError('Surface view was disposed before it mounted'));
    }
  }

  private async mount(): Promise<void> {
    if (this.mounting || this.mounted || this.disposed) return;
    this.mounting = true;
    this.status.textContent = 'Loading surface view…';
    try {
      const assets = await this.loadAssets();
      if (this.disposed) throw abortError('Surface view was disposed while loading');

      const measured = this.container.getBoundingClientRect();
      const width = finiteSize(this.options.width, finiteSize(measured.width, 640));
      const height = finiteSize(this.options.height, finiteSize(measured.height, 480));
      this.stage.style.minHeight = `${height}px`;
      const viewer = new NeuroSurfaceViewer(
        this.stage,
        width,
        height,
        {
          preset: this.options.preset
        },
        'lateral'
      );
      if (viewer.initializationFailed) {
        viewer.dispose();
        throw new Error('WebGL is unavailable; the surface view could not be initialized.');
      }
      this.currentViewer = viewer;
      this.buildSurfaces(assets);
      this.reportController = new ReportSceneController(viewer, this.manifest, {
        ...(this.viewGroup ? { bilateralGroup: this.viewGroup } : {}),
        initialView: this.options.initialView,
        hemisphereGap: this.options.hemisphereGap,
        ...(this.options.layout === undefined ? {} : { layout: this.options.layout }),
        ...(this.options.initialBrainView === undefined
          ? {}
          : { initialBrainView: this.options.initialBrainView }),
        ...(this.options.headlight === undefined ? {} : { headlight: this.options.headlight }),
        ...(this.options.fov === undefined ? {} : { fov: this.options.fov }),
        ...(this.options.fitMargin === undefined ? {} : { fitMargin: this.options.fitMargin }),
        ...(this.options.oblique === undefined ? {} : { oblique: this.options.oblique }),
        ...(this.options.fitInsets === undefined ? {} : { fitInsets: this.options.fitInsets })
      });
      this.reportTarget = createReportSceneControlTarget(this.reportController);
      this.mounted = true;
      this.status.remove();
      // A variant chosen before mounting is applied before the first pose.
      const initialVariant = Object.values(this.manifest.geometries)[0];
      if (this.selectedVariant && initialVariant &&
          this.selectedVariant !== sceneGeometryInitialVariant(initialVariant)) {
        this.applySurfaceVariant(this.selectedVariant);
      }

      this.selectLayer(this.selectedLayer);
      if (this.options.layout === 'anatomical') {
        this.setBrainView(
          this.selectedBrainView ?? this.options.initialBrainView ?? 'oblique'
        );
      } else {
        this.setView(this.selectedView);
      }

      if (this.options.controls) {
        this.reportControls = new ReportControls(
          this.reportTarget,
          { filename: `${this.manifest.id}.png` }
        );
        this.root.insertBefore(this.reportControls.element, this.stage);
      }
      this.resolveReady();
    } catch (error) {
      if (this.disposed && asError(error).name === 'AbortError') return;
      const failure = asError(error);
      this.renderError(failure);
      this.rejectReady(failure);
    } finally {
      this.mounting = false;
    }
  }

  private async loadAssets(): Promise<Map<string, SceneTypedArray>> {
    const loaded = new Map<string, SceneTypedArray>();
    await Promise.all(Object.values(this.manifest.assets).map(async descriptor => {
      const values = await loadSceneAsset(descriptor, {
        signal: this.abortController.signal,
        ...(this.options.fetcher === undefined ? {} : { fetcher: this.options.fetcher }),
        ...(this.options.baseUrl === undefined ? {} : { baseUrl: this.options.baseUrl })
      });
      loaded.set(descriptor.id, values);
    }));
    // Reject malformed categorical bytes before allocating WebGL resources.
    for (const layer of Object.values(this.manifest.layers)) {
      if (layer.role !== 'reference') continue;
      for (const ref of Object.values(layer.values)) {
        const membership = this.requireFloat32(loaded, ref.values);
        for (const value of membership) {
          if (value !== 0 && value !== 1) throw new TypeError(`Reference ${layer.id} membership must be binary`);
        }
      }
    }
    return loaded;
  }

  private buildSurfaces(assets: Map<string, SceneTypedArray>): void {
    if (!this.currentViewer) throw new Error('Viewer was not initialized');
    for (const geometryManifest of Object.values(this.manifest.geometries)) {
      const vertices = this.requireFloat32(assets, geometryManifest.vertices);
      const faces = this.requireUint32(assets, geometryManifest.faces);
      const curvature = geometryManifest.curvature
        ? this.requireFloat32(assets, geometryManifest.curvature)
        : null;
      for (let index = 0; index < faces.length; index += 1) {
        if (faces[index]! >= geometryManifest.vertexCount) {
          throw new Error(
            `Geometry ${geometryManifest.id} face index ${faces[index]} exceeds vertex count`
          );
        }
      }
      if (geometryManifest.variants) {
        // Own every embedding: the displayed geometry is rewritten in place.
        const positions = new Map<string, Float32Array>();
        for (const [name, assetId] of Object.entries(geometryManifest.variants)) {
          positions.set(name, new Float32Array(this.requireFloat32(assets, assetId)));
        }
        this.variantPositions.set(geometryManifest.id, positions);
      }
      const geometry = new SurfaceGeometry(
        vertices,
        faces,
        geometryManifest.hemisphere,
        curvature,
        false
      );
      const style = this.currentViewer.stylePreset;
      const surface = new MultiLayerNeuroSurface(geometry, {
        baseColor: style.material.baseColor,
        materialType: style.material.materialType,
        metalness: style.material.metalness,
        roughness: style.material.roughness,
        curvatureOptions: style.curvature,
        shading: {
          ...(style.lighting.silhouetteDarkening === undefined
            ? {} : { silhouetteDarkening: style.lighting.silhouetteDarkening }),
          ...(style.lighting.thresholdOutline === undefined
            ? {} : { thresholdOutline: style.lighting.thresholdOutline }),
          ...(style.lighting.thresholdOutlineShade === undefined
            ? {} : { thresholdOutlineShade: style.lighting.thresholdOutlineShade }),
          ...(style.lighting.overlayEmission === undefined
            ? {} : { overlayEmission: style.lighting.overlayEmission })
        },
        showCurvature: Boolean(curvature),
        useGPUCompositing: false,
        ...(curvature === null ? {} : { curvature })
      });

      for (const layerManifest of Object.values(this.manifest.layers)) {
        const valueManifest = layerManifest.values[geometryManifest.id];
        if (!valueManifest) continue;
        const values = this.requireFloat32(assets, valueManifest.values);
        const indices = valueManifest.indices
          ? this.requireUint32(assets, valueManifest.indices)
          : null;
        if (indices) {
          for (let index = 0; index < indices.length; index += 1) {
            if (indices[index]! >= geometryManifest.vertexCount) {
              throw new Error(
                `Layer ${layerManifest.id} index ${indices[index]} exceeds vertex count`
              );
            }
          }
        }
        if (layerManifest.role === 'reference') {
          surface.addLayer(new ReferenceLayer(layerManifest.id, values, layerManifest.color, {
            visible: layerManifest.visible ?? true,
            opacity: layerManifest.opacity ?? 1,
            presentation: {
              label: layerManifest.label,
              ...(layerManifest.provenance ? { provenance: layerManifest.provenance } : {})
            }
          }));
          continue;
        }
        surface.addLayer(createSceneDataLayer(
          layerManifest,
          values,
          indices,
          layerManifest.id === this.selectedLayer
        ));
      }
      this.currentViewer.addSurface(surface, geometryManifest.id);
      this.surfaces.push({
        id: geometryManifest.id,
        hemisphere: geometryManifest.hemisphere,
        surface
      });
    }

    if (this.surfaces.length > 1) {
      if (!this.options.bilateralGroup) {
        throw new Error('Multiple report surfaces require an explicit bilateralGroup option');
      }
      const registration = this.currentViewer.registerBilateralSurfaceGroup(
        this.options.bilateralGroup
      );
      if (!registration.ok) {
        throw new Error(`Invalid report bilateralGroup: ${registration.message}`);
      }
      this.viewGroup = registration.group;
    } else if (this.options.bilateralGroup) {
      const registration = this.currentViewer.registerBilateralSurfaceGroup(
        this.options.bilateralGroup
      );
      if (!registration.ok) {
        throw new Error(`Invalid report bilateralGroup: ${registration.message}`);
      }
      this.viewGroup = registration.group;
    }
  }

  private requireFloat32(
    assets: Map<string, SceneTypedArray>,
    id: string
  ): Float32Array {
    const values = assets.get(id);
    if (!(values instanceof Float32Array)) {
      throw new Error(`Asset ${id} was not loaded as Float32Array`);
    }
    return values;
  }

  private requireUint32(
    assets: Map<string, SceneTypedArray>,
    id: string
  ): Uint32Array {
    const values = assets.get(id);
    if (!(values instanceof Uint32Array)) {
      throw new Error(`Asset ${id} was not loaded as Uint32Array`);
    }
    return values;
  }

  private renderError(error: Error): void {
    this.reportControls?.dispose();
    this.reportControls = null;
    this.reportTarget?.dispose();
    this.reportTarget = null;
    this.reportController?.dispose();
    this.reportController = null;
    this.currentViewer?.dispose();
    this.currentViewer = null;
    this.surfaces.length = 0;
    this.viewGroup = null;
    this.mounted = false;
    this.status.setAttribute('role', 'alert');
    this.status.style.color = '#991b1b';
    this.status.style.background = '#fef2f2';
    this.status.textContent = `Surface view unavailable: ${error.message}`;
    if (!this.status.isConnected) this.stage.appendChild(this.status);
    try {
      this.options.onError?.(error);
    } catch {
      // Observer failures must not replace the mount failure or leave ready pending.
    }
  }
}

/**
 * Mount a portable SurfView scene into an ordinary DOM element.
 *
 * Validation is synchronous and happens before an observer, fetch, animation
 * frame, or WebGL context is created. Runtime failures are also rendered in the
 * mount so knitted/static reports never degrade to an unexplained blank panel.
 */
export function mountSurfView(
  container: HTMLElement,
  manifest: SurfViewSceneManifest,
  options: MountSurfViewOptions = {}
): SurfViewMountHandle {
  if (!(container instanceof HTMLElement)) {
    throw new TypeError('mountSurfView requires an HTMLElement container');
  }
  validateSceneManifest(manifest);
  return new SceneMount(container, manifest, options);
}
