import { normalizeMagnitudeOpacity } from '../layers/magnitudeOpacity';
import type { MagnitudeOpacity } from '../layers/magnitudeOpacity';

export const SURFVIEW_SCENE_SCHEMA = 'surfview.scene.v1' as const;
/** Required for persistent references; v1 runtimes reject this version. */
export const SURFVIEW_SCENE_SCHEMA_V2 = 'surfview.scene.v2' as const;

export type SceneHemisphere = 'left' | 'right';
export type SceneAssetDType = 'float32' | 'uint32';
export type SceneAssetRole = 'vertices' | 'faces' | 'curvature' | 'values' | 'indices';

export interface SceneAssetDescriptor {
  id: string;
  role: SceneAssetRole;
  dtype: SceneAssetDType;
  shape: number[];
  byteLength: number;
  sha256: string;
  endianness: 'little';
  encoding?: 'base64';
  data?: string;
  uri?: string;
  metadata?: Record<string, unknown>;
}

export interface SceneGeometryManifest {
  id: string;
  hemisphere: SceneHemisphere;
  vertices: string;
  faces: string;
  curvature?: string;
  /**
   * Optional alternative embeddings that share this topology, curvature and
   * per-vertex data (for example inflated, pial and white): variant name ->
   * vertices asset id. `vertices` must be one of the listed assets; it is the
   * initial embedding. Every geometry in a scene lists the same names, so one
   * switch changes both hemispheres. Runtimes without variant support ignore
   * this field and show `vertices`.
   */
  variants?: Record<string, string>;
  vertexCount: number;
  faceCount: number;
  metadata?: Record<string, unknown>;
}

export interface SceneLayerValuesManifest {
  values: string;
  indices?: string;
}

export interface SceneLayerLegend {
  title?: string;
  units?: string;
  visible?: boolean;
  metadata?: Record<string, unknown>;
}

interface SceneLayerCommon {
  id: string;
  label?: string;
  values: Record<string, SceneLayerValuesManifest>;
  opacity?: number;
  visible?: boolean;
  units?: string;
  legend?: SceneLayerLegend;
  metadata?: Record<string, unknown>;
  provenance?: Record<string, unknown>;
}

export interface SceneMapLayerManifest extends SceneLayerCommon {
  role?: 'map';
  colorMap: string | string[];
  limits: [number, number];
  threshold?: [number, number];
  /** Optional fade by |value|; see `MagnitudeOpacity`. Older runtimes ignore it. */
  magnitudeOpacity?: MagnitudeOpacity;
}

export interface SceneReferenceLayerManifest extends SceneLayerCommon {
  role: 'reference';
  label: string;
  /** Explicit display sRGB colour, #rrggbb. */
  color: string;
  /** Dense binary membership at each vertex. Boundary is the 0.5 contour. */
  boundary: 'midpoint';
  colorMap?: never;
  limits?: never;
  threshold?: never;
  magnitudeOpacity?: never;
  legend?: never;
  units?: never;
}

export type SurfViewSceneLayerManifest = SceneMapLayerManifest | SceneReferenceLayerManifest;

export interface SurfViewSceneManifest {
  schemaVersion: typeof SURFVIEW_SCENE_SCHEMA | typeof SURFVIEW_SCENE_SCHEMA_V2;
  id: string;
  assets: Record<string, SceneAssetDescriptor>;
  geometries: Record<string, SceneGeometryManifest>;
  layers: Record<string, SurfViewSceneLayerManifest>;
  selectedLayer?: string;
  metadata?: Record<string, unknown>;
  provenance?: Record<string, unknown>;
}

export class SceneManifestError extends Error {
  readonly path: string;

  constructor(path: string, message: string) {
    super(`${path}: ${message}`);
    this.name = 'SceneManifestError';
    this.path = path;
  }
}

const BYTES_PER_ELEMENT: Record<SceneAssetDType, number> = {
  float32: 4,
  uint32: 4
};

function requireNonEmpty(value: unknown, path: string): asserts value is string {
  if (typeof value !== 'string' || value.trim().length === 0) {
    throw new SceneManifestError(path, 'must be a non-empty string');
  }
}

function requirePositiveInteger(value: unknown, path: string): asserts value is number {
  if (!Number.isInteger(value) || (value as number) <= 0) {
    throw new SceneManifestError(path, 'must be a positive integer');
  }
}

function requireFinitePair(value: unknown, path: string): asserts value is [number, number] {
  if (!Array.isArray(value) || value.length !== 2 ||
      !value.every(item => typeof item === 'number' && Number.isFinite(item)) ||
      value[0] > value[1]) {
    throw new SceneManifestError(path, 'must be an ordered pair of finite numbers');
  }
}

function shapeElements(shape: number[], path: string): number {
  if (!Array.isArray(shape) || shape.length === 0) {
    throw new SceneManifestError(path, 'must contain at least one dimension');
  }
  return shape.reduce((total, dimension, index) => {
    requirePositiveInteger(dimension, `${path}[${index}]`);
    return total * dimension;
  }, 1);
}

function requireAsset(
  manifest: SurfViewSceneManifest,
  assetId: string,
  path: string,
  role?: SceneAssetRole
): SceneAssetDescriptor {
  requireNonEmpty(assetId, path);
  const asset = manifest.assets[assetId];
  if (!asset) throw new SceneManifestError(path, `references unknown asset ${assetId}`);
  if (role && asset.role !== role) {
    throw new SceneManifestError(path, `expected ${role} asset, received ${asset.role}`);
  }
  return asset;
}

const VARIANT_NAME = /^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$/;

/** Validate one geometry's variant table and return its names. */
function validateGeometryVariants(
  manifest: SurfViewSceneManifest,
  geometryId: string,
  geometry: SceneGeometryManifest
): string[] {
  const path = `$.geometries.${geometryId}.variants`;
  const variants = geometry.variants;
  if (variants === null || typeof variants !== 'object' || Array.isArray(variants)) {
    throw new SceneManifestError(path, 'must map variant names to vertices assets');
  }
  const entries = Object.entries(variants);
  if (entries.length < 2) {
    throw new SceneManifestError(path, 'must list at least two embeddings');
  }
  let includesBase = false;
  for (const [name, assetId] of entries) {
    if (!VARIANT_NAME.test(name)) {
      throw new SceneManifestError(`${path}.${name}`, 'variant names use letters, digits, _, . and -');
    }
    if (typeof assetId !== 'string') {
      throw new SceneManifestError(`${path}.${name}`, 'must name a vertices asset');
    }
    const asset = requireAsset(manifest, assetId, `${path}.${name}`, 'vertices');
    if (asset.dtype !== 'float32' || asset.shape.join('x') !== `${geometry.vertexCount}x3`) {
      throw new SceneManifestError(`${path}.${name}`, 'must be float32 with shape [vertexCount, 3]');
    }
    if (assetId === geometry.vertices) includesBase = true;
  }
  if (!includesBase) {
    throw new SceneManifestError(path, 'must include the geometry vertices asset');
  }
  return entries.map(([name]) => name);
}

/** The initial variant name of a geometry, or null without variants. */
export function sceneGeometryInitialVariant(geometry: SceneGeometryManifest): string | null {
  if (!geometry.variants) return null;
  const match = Object.entries(geometry.variants).find(([, assetId]) => assetId === geometry.vertices);
  return match ? match[0] : null;
}

export function validateSceneManifest(manifest: SurfViewSceneManifest): SurfViewSceneManifest {
  if (!manifest || typeof manifest !== 'object') {
    throw new SceneManifestError('$', 'must be an object');
  }
  if (manifest.schemaVersion !== SURFVIEW_SCENE_SCHEMA &&
      manifest.schemaVersion !== SURFVIEW_SCENE_SCHEMA_V2) {
    throw new SceneManifestError(
      '$.schemaVersion',
      `unsupported schema ${String(manifest.schemaVersion)}`
    );
  }
  requireNonEmpty(manifest.id, '$.id');

  const assetEntries = Object.entries(manifest.assets ?? {});
  if (assetEntries.length === 0) {
    throw new SceneManifestError('$.assets', 'must contain at least one asset');
  }
  for (const [assetId, asset] of assetEntries) {
    requireNonEmpty(assetId, `$.assets.${assetId}`);
    if (asset.id !== assetId) {
      throw new SceneManifestError(`$.assets.${assetId}.id`, 'must match its object key');
    }
    if (asset.endianness !== 'little') {
      throw new SceneManifestError(`$.assets.${assetId}.endianness`, 'must be little');
    }
    if (!(asset.dtype in BYTES_PER_ELEMENT)) {
      throw new SceneManifestError(`$.assets.${assetId}.dtype`, 'must be float32 or uint32');
    }
    const expectedBytes = shapeElements(asset.shape, `$.assets.${assetId}.shape`) *
      BYTES_PER_ELEMENT[asset.dtype];
    if (asset.byteLength !== expectedBytes) {
      throw new SceneManifestError(
        `$.assets.${assetId}.byteLength`,
        `expected ${expectedBytes}, received ${asset.byteLength}`
      );
    }
    if (!/^[a-f0-9]{64}$/.test(asset.sha256)) {
      throw new SceneManifestError(`$.assets.${assetId}.sha256`, 'must be a lowercase SHA-256');
    }
    const sourceCount = Number(typeof asset.data === 'string') + Number(typeof asset.uri === 'string');
    if (sourceCount !== 1) {
      throw new SceneManifestError(
        `$.assets.${assetId}`,
        'must contain exactly one of data or uri'
      );
    }
    if (asset.data && asset.encoding !== 'base64') {
      throw new SceneManifestError(`$.assets.${assetId}.encoding`, 'inline data must use base64');
    }
  }

  const geometryEntries = Object.entries(manifest.geometries ?? {});
  if (geometryEntries.length === 0) {
    throw new SceneManifestError('$.geometries', 'must contain at least one geometry');
  }
  const hemispheres = new Set<SceneHemisphere>();
  // Variant names shared by every geometry: null before the first geometry,
  // '' when geometries carry no variants.
  let variantKey: string | null = null;
  for (const [geometryId, geometry] of geometryEntries) {
    if (geometry.id !== geometryId) {
      throw new SceneManifestError(`$.geometries.${geometryId}.id`, 'must match its object key');
    }
    if (geometry.hemisphere !== 'left' && geometry.hemisphere !== 'right') {
      throw new SceneManifestError(
        `$.geometries.${geometryId}.hemisphere`,
        'must be left or right'
      );
    }
    if (hemispheres.has(geometry.hemisphere)) {
      throw new SceneManifestError(
        `$.geometries.${geometryId}.hemisphere`,
        `duplicates ${geometry.hemisphere} geometry`
      );
    }
    hemispheres.add(geometry.hemisphere);
    requirePositiveInteger(geometry.vertexCount, `$.geometries.${geometryId}.vertexCount`);
    requirePositiveInteger(geometry.faceCount, `$.geometries.${geometryId}.faceCount`);
    const vertices = requireAsset(
      manifest,
      geometry.vertices,
      `$.geometries.${geometryId}.vertices`,
      'vertices'
    );
    const faces = requireAsset(
      manifest,
      geometry.faces,
      `$.geometries.${geometryId}.faces`,
      'faces'
    );
    if (vertices.dtype !== 'float32' || vertices.shape.join('x') !== `${geometry.vertexCount}x3`) {
      throw new SceneManifestError(
        `$.geometries.${geometryId}.vertices`,
        'must be float32 with shape [vertexCount, 3]'
      );
    }
    if (faces.dtype !== 'uint32' || faces.shape.join('x') !== `${geometry.faceCount}x3`) {
      throw new SceneManifestError(
        `$.geometries.${geometryId}.faces`,
        'must be uint32 with shape [faceCount, 3]'
      );
    }
    if (geometry.variants !== undefined) {
      const names = validateGeometryVariants(manifest, geometryId, geometry);
      const key = names.slice().sort().join('\u0000');
      if (variantKey === null) {
        variantKey = key;
      } else if (variantKey !== key) {
        throw new SceneManifestError(
          `$.geometries.${geometryId}.variants`,
          'must list the same variant names as every other geometry'
        );
      }
    } else if (variantKey !== null && variantKey !== '') {
      throw new SceneManifestError(
        `$.geometries.${geometryId}.variants`,
        'must be present when another geometry lists variants'
      );
    } else {
      variantKey = '';
    }
    if (geometry.curvature) {
      const curvature = requireAsset(
        manifest,
        geometry.curvature,
        `$.geometries.${geometryId}.curvature`,
        'curvature'
      );
      if (curvature.dtype !== 'float32' || curvature.shape[0] !== geometry.vertexCount) {
        throw new SceneManifestError(
          `$.geometries.${geometryId}.curvature`,
          'must be float32 with one value per vertex'
        );
      }
    }
  }

  const layerEntries = Object.entries(manifest.layers ?? {});
  if (layerEntries.length === 0) {
    throw new SceneManifestError('$.layers', 'must contain at least one layer');
  }
  if (!layerEntries.some(([, layer]) => layer.role !== 'reference')) {
    throw new SceneManifestError('$.layers', 'must contain at least one quantitative map');
  }
  if (layerEntries.filter(([, layer]) => layer.role === 'reference').length > 1) {
    throw new SceneManifestError('$.layers', 'supports at most one reference');
  }
  for (const [layerId, layer] of layerEntries) {
    if (layer.role !== undefined && layer.role !== 'map' && layer.role !== 'reference') {
      throw new SceneManifestError(`$.layers.${layerId}.role`, 'must be map or reference');
    }
    if (layerId === 'base' || layerId === 'curvature') {
      throw new SceneManifestError(`$.layers.${layerId}.id`, 'reserved anatomical layer ID');
    }
    if (layer.visible !== undefined && typeof layer.visible !== 'boolean') {
      throw new SceneManifestError(`$.layers.${layerId}.visible`, 'must be a boolean');
    }
    if (layer.id !== layerId) {
      throw new SceneManifestError(`$.layers.${layerId}.id`, 'must match its object key');
    }
    if (layer.role === 'reference') {
      if (manifest.schemaVersion !== SURFVIEW_SCENE_SCHEMA_V2) {
        throw new SceneManifestError(`$.layers.${layerId}`, 'references require surfview.scene.v2');
      }
      requireNonEmpty(layer.label, `$.layers.${layerId}.label`);
      if (typeof layer.color !== 'string' || !/^#[a-fA-F0-9]{6}$/.test(layer.color)) {
        throw new SceneManifestError(`$.layers.${layerId}.color`, 'must be #rrggbb');
      }
      if (layer.boundary !== 'midpoint') {
        throw new SceneManifestError(`$.layers.${layerId}.boundary`, 'must be midpoint');
      }
      for (const field of ['colorMap', 'limits', 'threshold', 'magnitudeOpacity', 'legend', 'units']) {
        if (field in layer) throw new SceneManifestError(`$.layers.${layerId}.${field}`, 'not supported for references');
      }
      if (Object.keys(layer.values ?? {}).length !== geometryEntries.length) {
        throw new SceneManifestError(`$.layers.${layerId}.values`, 'reference requires every geometry');
      }
    } else {
      requireFinitePair(layer.limits, `$.layers.${layerId}.limits`);
      if (layer.threshold) requireFinitePair(layer.threshold, `$.layers.${layerId}.threshold`);
      if (layer.magnitudeOpacity !== undefined) {
        try {
          normalizeMagnitudeOpacity(layer.magnitudeOpacity);
        } catch (error) {
          throw new SceneManifestError(
            `$.layers.${layerId}.magnitudeOpacity`,
            error instanceof Error ? error.message : String(error)
          );
        }
      }
    }
    if (layer.opacity !== undefined &&
        (!Number.isFinite(layer.opacity) || layer.opacity < 0 || layer.opacity > 1)) {
      throw new SceneManifestError(`$.layers.${layerId}.opacity`, 'must be between 0 and 1');
    }
    const valuesEntries = Object.entries(layer.values ?? {});
    if (valuesEntries.length === 0) {
      throw new SceneManifestError(`$.layers.${layerId}.values`, 'must not be empty');
    }
    for (const [geometryId, valueRef] of valuesEntries) {
      const geometry = manifest.geometries[geometryId];
      if (!geometry) {
        throw new SceneManifestError(
          `$.layers.${layerId}.values.${geometryId}`,
          'references unknown geometry'
        );
      }
      const values = requireAsset(
        manifest,
        valueRef.values,
        `$.layers.${layerId}.values.${geometryId}.values`,
        'values'
      );
      if (values.dtype !== 'float32') {
        throw new SceneManifestError(
          `$.layers.${layerId}.values.${geometryId}.values`,
          'must be float32'
        );
      }
      if (layer.role === 'reference' && (valueRef.indices !== undefined ||
          values.shape.length !== 1 || values.shape[0] !== geometry.vertexCount)) {
        throw new SceneManifestError(`$.layers.${layerId}.values.${geometryId}`, 'reference requires dense [vertexCount] membership without indices');
      }
      if (valueRef.indices) {
        const indices = requireAsset(
          manifest,
          valueRef.indices,
          `$.layers.${layerId}.values.${geometryId}.indices`,
          'indices'
        );
        if (indices.dtype !== 'uint32' || indices.shape[0] !== values.shape[0]) {
          throw new SceneManifestError(
            `$.layers.${layerId}.values.${geometryId}.indices`,
            'must be uint32 with one index per value'
          );
        }
      } else if (values.shape[0] !== geometry.vertexCount) {
        throw new SceneManifestError(
          `$.layers.${layerId}.values.${geometryId}.values`,
          'must contain one value per vertex when indices are absent'
        );
      }
    }
  }
  if (manifest.selectedLayer && !manifest.layers[manifest.selectedLayer]) {
    throw new SceneManifestError('$.selectedLayer', 'references unknown layer');
  }
  if (manifest.selectedLayer && manifest.layers[manifest.selectedLayer]?.role === 'reference') {
    throw new SceneManifestError('$.selectedLayer', 'must select a quantitative map');
  }
  return manifest;
}
